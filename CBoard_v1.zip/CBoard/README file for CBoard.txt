README file for CBoard

To run CBoard on demonstration files:

1) Unpack ZIP files to chosen location.

2) Open MATLAB.

3) Navigate to "0. CBoard_v1" directory in Matlab.

4) Open the "A_CBoard.m" file. This is a MATLAB script that runs the analysis. It will can process multiple data files, or multiple data sheets within one file, or a combination of both.

5) Navigate up one directory in MATLAB, and add the "0. CBoard_v1" directory to the Matlab path (right click for this option).

6) To process the example data file used in the main text of the paper navigate down to the "1. Example 1_8_8x11" directory, and run the "A_CBoard" script from the MATLAB command window.

7) To process the extra example data files navigate to the "2. Example 2_Cefto_Data" directory and run the "A_CBoard" script from the MATLAB command window.


Notes of data file syntax:
See the example data files and follow their syntax.
A1 contains the antibiotic name and concentration serially diluted down the plate. The format is "IDX_(units)" or "IDX (units)". Keep this short to avoid Matlab table variable length problems.
A2 contains the antibiotic name and concentration serially diluted accross the plate in the same format.

Row 4 starting in A4 and going down contains the A1 associated concentration values.
B3 and across contains the A2 associated concentration values.

Variable checkerboard data sizes are automatically accommodated. Replicate plate analyses are not currently supported. We perform checkerboards in triplicate, and average the plate results prior to running CBoard, Eventually replicate analysis will be added.
