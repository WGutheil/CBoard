function [sumFIC, y_FIC] = He_1D_of_Bi_minFICI_func(x_FIC, x_var, n)
% Function to find the minimum of 1D of a bi-dimensionally fit Hill
% function based 2D checkerboard model. x are the best fit parameters and
% x_FIC The FICI = min(y_FIC + x_FIC). First calculates y_FIC as a func of
% x_FIC and then adds them together. Taken from Hd_... 
% n is n_FICI, the exponential term used to force the weighting curve to
% pass through the point (x_FICI, 0.5) in the equation x^n + y^n = 1, 
% where x_FICE is the x_FICI from the % 1D fits (Part II of the analysis.
%
% Unpack the variables. 
% 
% sprintf('Here\n')
    lx=length(x_var);
    FIC0_x=x_var(1);
    FIC0_y=x_var(2);
    k_x=x_var(3);
    k_y=x_var(3); 
    k_y=x_var(4);

    if lx<5
        n_x=1;
    else
        n_x=x_var(5);
    end

    if lx<6
        n_y=1;
    else
        n_y=x_var(6);
    end

    % Calc in x->y dimension
    for i=1:length(x_FIC)   % Dont need the "i" for minimizing but can use 
                            % for nice plots.
                            % need to do in a loop since if x_FIC=0 second term blows up
                            % Need to replace with 0.
        if x_FIC(i)~=0
           y_FIC(i) = FIC0_y*(1/( 1 + (x_FIC(i)/k_x)^n_x )) *  abs(1-(x_FIC(i)/FIC0_x)^n) ...    % Hill term x weight term, abs to keep positive
                     + k_y*(abs(FIC0_x/x_FIC(i)-1))^(1/n_y) * abs((x_FIC(i)/FIC0_x)^n);             % inverse Hill term x weight term
        else
           y_FIC(i) = FIC0_y;        % if FIC_x=0 make inverse term 0
        end
    end

    sumFIC = (y_FIC + x_FIC);
    % pause
