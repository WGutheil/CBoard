function [A,B,Iso] = B_Fit_Main2(data, r_conc, c_conc, r_label, c_label, out_dir)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    
    %% Plot raw data
    fig1=figure('units','inches','position',[1 0.5 7 9.5]);
    [xticklabels, xticks]=mk_ticklabels(c_conc);
    [yticklabels, yticks]=mk_ticklabels(r_conc);
    % xblankticks= [0 1];
    % xblanklabels= {'' ''};
    % xticks = linspace(1, length(c_conc), numel(xticklabels));
    
    subplot(2,2,1);
    imagesc(data);
    set(gca, 'XTick', xticks, 'XTickLabel', xticklabels);
    set(gca, 'YTick', yticks, 'YTickLabel', yticklabels(:));
    xlabel(c_label, 'Interpreter','none');
    ylabel(r_label, 'Interpreter','none');
    title('A. Raw Data');
    colorbar;

    % Plot data as a contour plot in panel 4
    subplot(2,2,4);
    contourf(flip(data)); % Have to flip to align with other plots
    set(gca, 'XTick', xticks, 'XTickLabel', xticklabels);
    set(gca, 'YTick', yticks, 'YTickLabel', yticklabels(end:-1:1)); % flip this as well
    xlabel(c_label, 'Interpreter','none');
    ylabel(r_label, 'Interpreter','none');
    title('D. Raw Data Contour Plot');
    colorbar;
      
    %% Do fits
    % First determine how many columns and rows are suitable for fitting.
    % First columns.
    ic=Ba_icolfit(data,r_conc,c_conc);
    %lic=length(ic);
    % Then rows. Need to transpose data, and swap r_conc and c_conc to keep
    % everything aligned.
    ir=Ba_icolfit(data',c_conc',r_conc')';
    %lir=length(ir);
    
    try     % try to extract roots from labels. First for columns
        c_id=[strfind(c_label,'_') strfind(c_label,' ') strfind(c_label,'(')];  % id separators
        c_id=min(c_id);
        if length(c_id)==0
            c_root='';
        elseif c_id==1 % No root
            c_root=''; % Make empty
        else
            c_root=c_label(1:c_id-1); % Extract root
        end
    catch
        c_root='';
    end

    try     % Then rows
        r_id=[strfind(r_label,'_') strfind(r_label,' ') strfind(r_label,'(')];  % id separators
        r_id=min(r_id);
        if length(r_id)==0
            r_root='';
        elseif r_id==1 % No root
            r_root=''; % Make empty
        else
            r_root=r_label(1:r_id-1); % Extract root
        end
    catch
        r_root='';
    end

    % try     % same for rows
    %     r_id=[strfind(r_label,'_') strfind(r_label,' ') strfind(r_label,'(')];
    %     r_id=min(r_id);
    %     r_root=r_label(1:r_id-1);
    % end

    %% Column wise fits
    if length(ic)>0

        % Do the fit
        A=Bb_chk_col_fit(data,r_conc,c_conc); 

        % Assign labels and roots to data structure
        A.c_label=c_label;
        A.c_root=c_root;
        A.r_label=r_label;                  % Add here for use later
        A.r_root=r_root;
        
        % Set up for plotting using equispaced row and column labels
        % rather than numerical spacing
        [xticklabels, xticks]=mk_ticklabels(A.c_concic);
        [yticklabels, yticks]=mk_ticklabels(A.r_conc);
        xblankticks= [0 1];
        xblanklabels= {'' ''};
        
        % Plots
        figure(fig1);
        subplot(7,2,2);
        imagesc(A.dataic);
        set(gca, 'XTick', xblankticks, 'XTickLabel', xblanklabels);
        set(gca, 'YTick', yticks, 'YTickLabel', yticklabels);
        %xylabel(A.c_concic,A.r_conc)
        title('B. Fit-able Column Data Raw');
        colorbar;
        
        subplot(7,2,4);
        imagesc(A.pred);
        %xylabel(A.c_concic,A.r_conc);
        set(gca, 'XTick', xblankticks, 'XTickLabel', xblanklabels);
        set(gca, 'YTick', yticks, 'YTickLabel', yticklabels(:));
        ylabel(r_label,'Interpreter','none');
        title('Fit Predicted');
        colorbar;
        
        subplot(7,2,6);
        imagesc(A.resid);
        set(gca, 'XTick', xticks, 'XTickLabel', xticklabels);
        set(gca, 'YTick', yticks, 'YTickLabel', yticklabels(:));
        xlabel(c_label,'Interpreter','none');
        title('Fit Residuals');
        colorbar;
    else
        fprintf('No fit-able Columns\n');
        A.err='No fit-able columns';
    end
    
    %% Row wise - note: using transpose of rows and columns
    if length(ir)>0
        B=Bb_chk_col_fit(data',c_conc',r_conc');
        B.r_label=c_label;                    % Add here for use later, with swapped axes.
        B.r_root=c_root;
        B.c_label=r_label;
        B.c_root=r_root;

        figure(fig1)
        subplot(7,2,9);
        imagesc(B.dataic');
        [yticklabels, yticks]=mk_ticklabels(B.c_concic);
        [xticklabels, xticks]=mk_ticklabels(B.r_conc);
        xblankticks= [0 1];
        xblanklabels= {'' ''};
        
        set(gca, 'YTick', yticks, 'YTickLabel', yticklabels);
        set(gca, 'XTick', xblankticks, 'XTickLabel', xblanklabels);
        %xylabel(A.c_concic,A.r_conc)
        title('C. Fit-able Row Data Raw');
        colorbar
        
        subplot(7,2,11);
        imagesc(B.pred');
        %xylabel(A.c_concic,A.r_conc)
        set(gca, 'XTick', xblankticks, 'XTickLabel', xblanklabels);
        set(gca, 'YTick', yticks, 'YTickLabel', yticklabels);
        ylabel(r_label,'Interpreter','none');
        title('Fit Predicted')
        colorbar
        
        subplot(7,2,13)
        imagesc(B.resid')
        set(gca, 'XTick', xticks, 'XTickLabel', xticklabels);
        set(gca, 'YTick', yticks, 'YTickLabel', yticklabels(:));
        xlabel(c_label,'Interpreter','none');
        title('Fit Residuals')
        colorbar;
    else
        fprintf('No fit-able Rows\n');
        B.err='No fit-abel Rows';
    end
    %% Print Fig1
    mkdir(out_dir);
    sgtitle('Fig 1; Raw Data Col & Row Fit Results.pdf', 'Interpreter', 'None');
    print([out_dir,'\Fig1; Raw Data Col & Row Fit Results.pdf'],'-dpdf','-fillpage');
    % close(fig1)
    % close all   
    
    %% - Next, calculate isobologram
    if isfield(A, 'Ahigh') & isfield(B,'Ahigh')
        Ahigh=(A.Ahigh+B.Ahigh)/2;
        Alow=(A.Alow+B.Alow)/2;
        [Iso]=Bc_Isobolo(data,r_conc,c_conc,Alow,Ahigh);
        iiso=size(Iso.rvc,1);
        
    elseif isfield(A, 'Ahigh')
        Ahigh=A.Ahigh;
        Alow=A.Alow;
        [Iso]=Bc_Isobolo(data,r_conc,c_conc,Alow,Ahigh);
        iiso=size(Iso.rvc,1);

    elseif isfield(B, 'Ahigh')
        Ahigh=B.Ahigh;
        Alow=B.Alow;
        [Iso]=Bc_Isobolo(data,r_conc,c_conc,Alow,Ahigh);
        iiso=size(Iso.rvc,1);
    else
        fprintf('No fittable rows or columns \n');
        [Iso]=Bc_Isobolo(data,r_conc,c_conc,Alow,Ahigh);
        iiso=size(Iso.rvc,1);
    end
    
    %% Plot fits
    figure('units','inches','position',[1 .5 7 9.5]);
    % figure(fig2)
    
    % Plot column v conc fits
    if isfield(A, 'ic')
        subplot(3,2,1);
        plot(A.c_concic,A.Kf,".-",'MarkerSize',24);
        xlabel(A.c_label,'Interpreter','none');
        ylabel([ 'MIC_', A.r_label],'Interpreter','none');
        ylim([-Inf Inf]);
        xlim([0 Inf]);
        title(['A. Column MICs vs ' A.c_label],'Interpreter','none');
        hold on
        % To deal with large se's in plots
        hold on
        maxKf=max(A.Kf);
        maxKfse=max(A.Kf+A.seKf);
        imin=(A.Kf-A.seKf)<-0.1*maxKf;
        sump_Kf=A.Kf+A.seKf;
        sumn_Kf=A.Kf-A.seKf;
        if maxKfse>2*maxKf
            imax=(A.Kf+A.seKf)>1.5*maxKf;
            
            ylim([-0.1*maxKf Inf]);
            plot(A.c_concic(~imax),sump_Kf(~imax),'_r','MarkerSize',8,'LineWidth',2)
            plot(A.c_concic(imax),maxKf*1.5.*ones(size(A.c_concic(imax))),'^r','MarkerSize',8,'LineWidth',1.8)
            
            plot(A.c_concic(~imin),sumn_Kf(~imin),'_r','MarkerSize',8,'LineWidth',2)
            plot(A.c_concic(imin),-0.1*maxKf.*ones(size(A.c_concic(imin))),'vr','MarkerSize',8,'LineWidth',1.8)
            lgnd_str={'fit values'; '+se'; '+se above bound'; '-se'; '-se below bound'};
        else
            plot(A.c_concic,sump_Kf,'_r','MarkerSize',8,'LineWidth',1.8)
            plot(A.c_concic,sumn_Kf,'_r','MarkerSize',8,'LineWidth',1.8)
            lgnd_str={'fit values'; '+se';  '-se'};
        end
        hold off
        lgd=legend(lgnd_str);
        lgd.BackgroundAlpha = .6;
    end


        % plot(A.c_concic,A.Kf+A.seKf,'_k','MarkerSize',8,'LineWidth',1.8)
        % plot(A.c_concic,A.Kf-A.seKf,'_k','MarkerSize',8,'LineWidth',1.8)
        % hold off
        % legend(lgnd_str);
        % Calculate data FIC values        
%        A.dataFIC = min(A.c_concic/Iso.c_MIC0 + A.Kf/Iso.r_MIC0);   Dont
%        use. Isobologram MIC0s are inaccurate.
%        text(0.2*max(A.c_concic),0.8*max(A.Kf),[{'dataFICI'; '(using isobologram MIC0s) ='; num2str(A.dataFIC,3)}],'HorizontalAlignment','left');

    % Plot row v conc fits
    if isfield(B, 'ic')
        subplot(3,2,2);
        plot(B.c_concic,B.Kf,'.-','MarkerSize',24);
        xlabel([B.c_label],'Interpreter','none');
        ylabel([ 'MIC_', B.r_label],'Interpreter','none');
        ylim([0 Inf]);
        xlim([0 Inf]);
        title(['B. Row MICs vs ' B.c_label],'Interpreter','none');
        hold on
        maxKf=max(B.Kf);
        maxKfse=max(B.Kf+B.seKf);
        imin=(B.Kf-B.seKf)<-0.1*maxKf;
        sump_Kf=B.Kf+B.seKf;
        sumn_Kf=B.Kf-B.seKf;
        if maxKfse>2*maxKf
            imax=(B.Kf+B.seKf)>1.5*maxKf;
            
            ylim([-0.1*maxKf Inf]);
            plot(B.c_concic(~imax),sump_Kf(~imax),'_r','MarkerSize',8,'LineWidth',1.8)
            plot(B.c_concic(imax),maxKf*1.5.*ones(size(B.c_concic(imax))),'^r','MarkerSize',8,'LineWidth',1.8)
            
            plot(B.c_concic(~imin),sumn_Kf(~imin),'_r','MarkerSize',8,'LineWidth',1.8)
            plot(B.c_concic(imin),-0.1*maxKf.*ones(size(B.c_concic(imin))),'vr','MarkerSize',8,'LineWidth',1.8)
            lgnd_str={'fit values'; '+se'; '+se above bound'; '-se'; '-se below bound'};
        else
            plot(B.c_concic,sump_Kf,'_r','MarkerSize',8,'LineWidth',1.8)
            plot(B.c_concic,sumn_Kf,'_r','MarkerSize',8,'LineWidth',1.8)
            lgnd_str={'fit values'; '+se';  '-se'};
        end
        hold off
        lgd=legend(lgnd_str);
        lgd.BackgroundAlpha = .6;
    end
   
    % Plot isobologram
    if iiso>0
        subplot(3,2,3)
        plot(Iso.rvc(:,2),Iso.rvc(:,1),'.-','MarkerSize',24)
        xlabel(['MIC_', A.c_label],'Interpreter','none');
        ylabel(['MIC_', A.r_label],'Interpreter','none');
        ylim([0 Inf]);
        xlim([0 Inf]);
        title('C. Simple Isobologram')
        text(0.9*max(Iso.rvc(:,2)),0.9*max(Iso.rvc(:,1)),['dataFICI = ' num2str(Iso.dataFICI,3)],'HorizontalAlignment','right');
    end
    
    % Plot overlay
    subplot(3,2,4);
    hold off;
    if length(ic)>0,plot(A.c_concic,A.Kf,'.-','MarkerSize',20); end
    hold on;
    if length(ir)>0, plot(B.Kf,B.c_concic,".-",'MarkerSize',20); end
    if iiso>0 plot(Iso.rvc(:,2),Iso.rvc(:,1),".-",'MarkerSize',20); end
    hold off;
    title('D. Overlayed Fit MICs and Isobologram');
    % legend({'Column Fits' 'Row Fits (flipped)' 'Simple Isobologram'})
    xlabel(['MIC_', c_label],'Interpreter','none');
    ylabel(['MIC_', r_label],'Interpreter','none');
    ylim([0 Inf]);
    xlim([0 Inf]);
    
    % Build legend string array
    leg_str=[];
    if length(ic)>0,leg_str=[leg_str; "Column fits"]; end
    if length(ir)>0,leg_str=[leg_str,"Row Fits (flipped)"]; end
    if iiso>0,leg_str=[leg_str,"Simple Isobologram"]; end
    lgd=legend(leg_str);
    lgd.BackgroundAlpha = .6;

    % Plot column n v conc fit
    if length(ic)>0
        subplot(3,2,5);
        plot(A.c_concic,A.nf,".-",'MarkerSize',24);
        xlabel(A.c_label,'Interpreter','none');
        if length(A.r_root)>0
            y_txt=['n_' A.r_root];
        else
            y_txt=['n'];
        end
        ylabel(y_txt,'Interpreter','none');
        ylim([0 Inf]);
        xlim([0 Inf]);
        title('E. Column "n" fits');
        % To deal with large se's in plots
        hold on
        maxnf=max(A.nf);
        maxnfse=max(A.nf+A.senf);
        imin=(A.nf-A.senf)<-0.1*maxnf;
        sump_nf=A.nf+A.senf;
        sumn_nf=A.nf-A.senf;

        if maxnfse>2*maxnf
            imax=(A.nf+A.senf)>1.5*maxnf;
            ylim([-0.1*maxnf Inf]);
            plot(A.c_concic(~imax),sump_nf(~imax),'_r','MarkerSize',8,'LineWidth',1.8)
            plot(A.c_concic(imax),maxnf*1.5.*ones(size(A.c_concic(imax))),'^r','MarkerSize',8,'LineWidth',1.8)
            
            plot(A.c_concic(~imin),sumn_nf(~imin),'_r','MarkerSize',8,'LineWidth',1.8)
            plot(A.c_concic(imin),-0.1*maxnf.*ones(size(A.c_concic(imin))),'vr','MarkerSize',8,'LineWidth',1.8)
            lgnd_str={'fit values'; '+se'; '+se above bound'; '-se'; '-se below bound'};
        else
            plot(A.c_concic,sump_nf,'_r','MarkerSize',8,'LineWidth',1.8)
            plot(A.c_concic,sumn_nf,'_r','MarkerSize',8,'LineWidth',1.8)
            lgnd_str={'fit values'; '+se';  '-se'};
        end
        hold off
        lgd=legend(lgnd_str);
        lgd.BackgroundAlpha = .6;
    end

    if length(ir)>0
        subplot(3,2,6);
        plot(B.c_concic,B.nf,".-",'MarkerSize',24);
        xlabel(B.c_label,'Interpreter','none');
        if length(A.c_root)>0
            y_txt=['n_' A.c_root];
        else
            y_txt=['n'];
        end

        ylabel(y_txt,'Interpreter','none');
        ylim([0 Inf]);
        xlim([0 Inf]);
        title('F. Row "n" fits');
        hold on
        maxnf=max(B.nf);
        maxnfse=max(B.nf+B.senf);
        imin=(B.nf-B.senf)<-0.1*maxnf;
        sump_nf=B.nf+B.senf;
        sumn_nf=B.nf-B.senf;

        if maxnfse>2*maxnf
            imax=(B.nf+B.senf)>1.5*maxnf;
            ylim([-0.1*maxnf Inf]);
            plot(B.c_concic(~imax),sump_nf(~imax),'_r','MarkerSize',8,'LineWidth',1.8)
            plot(B.c_concic(imax),maxnf*1.5.*ones(size(B.c_concic(imax))),'^r','MarkerSize',8,'LineWidth',1.8)
            
            plot(B.c_concic(~imin),sumn_nf(~imin),'_r','MarkerSize',8,'LineWidth',1.8)
            plot(B.c_concic(imin),-0.1*maxnf.*ones(size(B.c_concic(imin))),'vr','MarkerSize',8,'LineWidth',1.8)
            lgnd_str={'fit values'; '+se'; '+se above bound'; '-se'; '-se below bound'};
        else
            plot(B.c_concic,sump_nf,'_r','MarkerSize',8,'LineWidth',1.8)
            plot(B.c_concic,sumn_nf,'_r','MarkerSize',8,'LineWidth',1.8)
            lgnd_str={'fit values'; '+se';  '-se'};
        end
        hold off
        lgd=legend(lgnd_str);
        lgd.BackgroundAlpha = .6;
    end
    
    sgtitle('Fig 2; Fit MIC and n Values and Isobologram Overlay', 'Interpreter', 'None');
    print([out_dir,'\Fig2; Fit MIC and n Values and Isobologram Overlay.pdf'],'-dpdf','-fillpage');

    % close(fig2);

end