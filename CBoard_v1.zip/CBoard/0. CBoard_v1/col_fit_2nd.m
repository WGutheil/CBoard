function [y_est, resid] = col_fit(x,r_conc,dataic)
    [lr, lic]=size(dataic);
    Amax=x(1);
    Amin=x(2);
    Knf=x(3:3+lic-1);
    nnf=x(3+lic:3+2*lic-1);
    for ii=1:lic
        y_est(:,ii) = Amax-(Amax-Amin)*r_conc.^nnf(ii)./(r_conc.^nnf(ii) + Knf(ii).^nnf(ii));
        % resid(:,ii) = dataic(:,ii) - y_est(:,ii);
        % plot(r_conc,y_est(:,ii),r_conc,dataic(:,ii),'*');
        % pause
    end
    resid=dataic-y_est;
end
