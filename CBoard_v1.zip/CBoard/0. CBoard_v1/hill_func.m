function [y] = hill(x,k,n)
%hill simple hill fnc y=1/1+(x/k)^n, vector x, scalar k and n
%   Detailed explanation goes here

    y=zeros(size(x)); % make y match x
    for i=1:length(x(:))
        y(i) = 1 / (1 + (x(i) / k)^n);
    end

end