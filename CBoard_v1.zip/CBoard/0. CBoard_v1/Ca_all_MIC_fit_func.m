function [rss, y_est, resid] = Ca_all_MIC_fit_func(x,x_MICs,y_MICs)
    MIC0=x(1);
    Kd=x(2);
    if length(x)==2
        n=1;
    else
        n=x(3);
    end
    y_est = MIC0./(1 + (x_MICs./Kd).^n);
    resid = (y_MICs - y_est);
    % plot(r_conc,y_est(:,ii),r_conc,dataic(:,ii),'*');
    % pause
    rss=sum(resid(:).*resid(:));
end
