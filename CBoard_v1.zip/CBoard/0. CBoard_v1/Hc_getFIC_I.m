function [tmp] = Hc_getFIC_I(x,Vxy,n_FICI)
%Hc_getFIC_I Uses Bi-fit Vxy initial estimate parameters and  x_FIC estimate
%and finds x_FIC that minimizes the minimizes the FICI in both xy and yx
%directions. 
%   Detailed explanation goes here
% Get the FICIs from a Bi-dimensional fit. 
% 
% ID Format: (axis value)_FICI_(fit dimension 2
% digits)(model id ##). OR FICI_(fit dimension)(models id)

f=@(x)He_1D_of_Bi_minFICI_func(x, Vxy, n_FICI);     % Function handle def for x-y curve fit
[x_FIC_xd, FICI_xd]=fmincon(f,x,[],[],[],[],0,2);   % Need constrained minimization
[t, y_FIC_xd] = f(x_FIC_xd);                        % This gives y_FIC value

f=@(x)He_1D_of_Bi_minFICI_func(x, Vxy([2 1 4 3 6 5]), n_FICI); 
                            % For y-x fit need to flip from x to y axes by 
                            % swaping x and y defined  
                            % fit variables for x y axes values
[y_FIC_yd, FICI_yd]=fminsearch(f, x);   % y-dim values
[tmp, x_FIC_yd] = f(y_FIC_yd);          % x-dim value

[x_FIC_sd x_FIC_avg] = std([x_FIC_xd x_FIC_yd]);  % Avg and sd x_FIC
x_FIC_se = x_FIC_sd/sqrt(2);                      % se

[y_FIC_sd y_FIC_avg] = std([y_FIC_xd y_FIC_yd]);  % Avg and sd y_FIC
y_FIC_se = y_FIC_sd/sqrt(2);                      % se

[FICI_sd FICI_avg] = std([FICI_xd FICI_yd]);      % Avg and sd y_FIC
FICI_se = FICI_sd/sqrt(2);                        % se
%x_FIC_se^2+y_FIC_se^2

tmp = ...
[x_FIC_xd  y_FIC_xd  FICI_xd;
 x_FIC_yd  y_FIC_yd  FICI_yd;
 x_FIC_avg y_FIC_avg FICI_avg;
 x_FIC_se  y_FIC_se  FICI_se];

% tmp(5,:) = 100*tmp(4,:)./tmp(3,:); % rse calc

tmp=array2table(tmp');
tmp.Properties.RowNames={'min_x_FIC' 'min_y_FIC' 'min_FICI'};
tmp.Properties.VariableNames={'x-dim' 'y-dim' 'avg' 'se'};

end