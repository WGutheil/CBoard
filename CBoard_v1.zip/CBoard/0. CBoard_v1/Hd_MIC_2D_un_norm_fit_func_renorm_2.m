function [rss, rss_y, rss_x, y_est, x_est, resid_y, resid_x] = Hd_MIC_2D_un_norm_fit_func_renorm(x, x_FICs, y_FICs,n)
% Function to fit checkerboard data to bi-directional Hill function.
% x is current parameter estimates (x_M/FIC0, y_M/FIC0, x_k, y_k, x_n, y_n).
% if x is only 4 values long uses value of 1 for x_n and y_n. M/FIC_x and
% M/FIC_y are the data to be fit.
% n is n_FICE, the exponential term used to force the weighting curve to
% pass through the point (x_FICI, 0.5), where x_FICE is the x_FICI estimate 
% from the % 1D fits (Part II of the analysis.
% 
% Unpack the variables. 
    lx=length(x);
    FIC0_x=x(1);
    FIC0_y=x(2);
    k_x=x(3);
    k_y=x(4); 

    if lx<5
        n_x=1;
    else
        n_x=x(5);
    end

    if lx<6
        n_y=1;
    else
        n_y=x(6);
    end

    % First calc in x->y dimension
    for i=1:length(x_FICs)   % need to do in a loop this time since if FIC_x=0 second term blows up
                             % Need to replace with 0
        if x_FICs(i)==0
           y_est(i) = FIC0_y;      % if FIC_x=0 then y=FIC0_y.
        elseif x_FICs(i)<=FIC0_x   % if FIC_x>0 and <=FIC0_x do full calc 
            y_est(i) = FIC0_y*(1/( 1 + (x_FICs(i)/k_x)^n_x )) *  (1-(x_FICs(i)/FIC0_x)^n) ...    % Hill term x weight term, abs to keep positive
                     + k_y*((FIC0_x/x_FICs(i)-1))^(1/n_y) * ((x_FICs(i)/FIC0_x)^n);             % inverse Hill term x weight term
        elseif x_FICs(i)>FIC0_x     % if x_FICs(i)> FIC0_x then project forward with weight of 1 into negative estimated y_est
            y_est(i) = -k_y*(-(FIC0_x/x_FICs(i)-1))^(1/n_y);
        end
    end

    resid_y=y_FICs-y_est;
    rss_y=sum(resid_y(:).*resid_y(:));
    
    % Then in y->x dimension

    clear x_est;
    for i=1:length(y_FICs)   

        if y_FICs(i)==0
           x_est(i) = FIC0_x;      
        elseif y_FICs(i)<=FIC0_y   
            x_est(i) = FIC0_x*(1/( 1 + (y_FICs(i)/k_y)^n_y )) *  (1-(y_FICs(i)/FIC0_y)^n) ...    % Hill term x weight term, abs to keep positive
                     + k_x*((FIC0_y/y_FICs(i)-1))^(1/n_x) * ((y_FICs(i)/FIC0_y)^n);             % inverse Hill term x weight term
        elseif y_FICs(i)>FIC0_y     
            x_est(i) = -k_x*(-(FIC0_y/y_FICs(i)-1))^(1/n_x);
        end
    end

    % figure
    % hold off
    % plot(y_MICs, x_MICs,'o')
    % hold on
    % plot(y_MICs,x_est,'.','MarkerSize',20)
    % plot(y_MICs, resid_x,'.','MarkerSize',20)
    % hold off
    
    resid_x=x_FICs-x_est;
    rss_x=sum(resid_x(:).*resid_x(:))/FIC0_x;

    % Un-weighted total sum of squares: 
    rss=rss_x+rss_y;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     %% Code to breakdown separate curves for direct and inverse hill function calcs - for debugging
%       Copy to separate script window to run interactively.
%
%     lx=length(x);
%     FIC0_x=x(1);
%     FIC0_y=x(2);
%     k_x=x(3);
%     k_y=x(3); % If only one k sent then makes both
%     k_y=x(4);
% 
%     if lx<5
%         n_x=1;
%     else
%         n_x=x(5);
%     end
% 
%     if lx<6
%         n_y=1;
%     else
%         n_y=x(6);
%     end
% 
% for i=1:length(x_FICs)   % need to do in a loop this time since if FIC_x=0 second term blows up
%                              % Need to replace with 0
%     if x_FICs(i)~=0
%         y_est_f(i) = FIC0_y*(1/( 1 + (x_FICs(i)/k_x)^n_x ));     %*  abs(1-(x_FICs(i)/FIC0_x)^n) ...    % Hill term x weight term, abs to keep positive
%         y_est_b(i) = k_y*(abs(FIC0_x/x_FICs(i)-1))^(1/n_y);     %*abs((x_FICs(i)/FIC0_x)^n);        % inverse Hill term x weight term
%     else
%          y_est_f(i) = 1;    
%          y_est_b(i) = FIC0_y;        % if FIC_x=0 make inverse term 0
% 
%     end
% end
% 
% for i=1:length(y_FICs)   % need to do in a loop this time since if MIC_x=0 second term blows up
%                         % Need to replace with 0
%     if y_FICs(i)~=0
%         x_est_f(i) = FIC0_x* (1/( 1 + (y_FICs(i)/k_y)^n_y )); % * abs(1-y_FICs(i)/FIC0_y)^n ...    % Hill term
%         x_est_b(i) = k_x*(abs(FIC0_y/y_FICs(i)-1))^(1/n_x); % *abs((y_FICs(i)/FIC0_y)^n ); % inverse Hill term
%     else
%          x_est_f(i) = 1;
%          x_est_b(i) = FIC0_x;        % if MIC_x=0 make inverse term 0
%     end
% end
% 
% figure
% hold off
% plot(x_FICs,y_FICs,'.','MarkerSize',20)
% hold on
% plot(x_FICs, y_est_f)
% plot(x_est_b,y_FICs)
% 
% plot(x_FICs,y_est_b)
% plot(x_est_f,y_FICs)
% 
% 
% plot(y_est_b,x_FICs)
% plot(y_FICs,x_est_f)
% 
% hold off


end
