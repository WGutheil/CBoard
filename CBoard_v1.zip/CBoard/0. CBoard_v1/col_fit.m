function rss = col_fit(x,r_conc,dataic)
    [lr, lic]=size(dataic);
    Azero=x(1);
    Ahigh=x(2);
    Knf=x(3:3+lic-1);
    nnf=x(3+lic:3+2*lic-1);
    for ii=1:lic
        y_est(:,ii) = Azero-(Azero-Ahigh)*r_conc.^nnf(ii)./(r_conc.^nnf(ii) + Knf(ii).^nnf(ii));
        resid(:,ii) = dataic(:,ii) - y_est(:,ii);
        % plot(r_conc,y_est(:,ii),r_conc,dataic(:,ii),'*');
        % pause
    end
    rss=sum(resid(:).*resid(:));
end
