format shortg
% cd('N:\Groups\Pharmacy\Workgrps\Gutheil Lab\Students\Nitish\Group\3. Papers\2. GSK Screen\1. Data\4. Checkerboard_Assay')
tmp=dir('*.xls*'); 
tmp=struct2cell(tmp);
fnames=tmp(1,:)';   % Extract file names.
Graphics_set;
   
[lfn, ~]= size(fnames);        % Get the number of file nanes.
clear tmp;
% clear rname
for i=1:length(fnames)  % get the fnames roots
    isf=strfind(fnames{i},'.');
    tmp=char(fnames{i});
    rname(i,:)={tmp([1:isf-1])};
end

ij=0;               % make a table of fnames snames
clear out_dir
for ifn=1:lfn
    snames=sheetnames(fnames{ifn});
    [lsn, ~]=size(snames);
    for isn=1:length(snames)
        ij=1+ij;
        out_dir{ij,1}=rname{ifn}; 
        out_dir{ij,2}=snames{isn};
    end
end
out_dir_table=cell2table(out_dir);          % Convert to table
clear out_dir; % To use again
[lfnu ~]=size(unique(out_dir_table(:,1)));  % Determine how many unique filenames
[lsnu ~]=size(unique(out_dir_table(:,2)));  % Determine how many unique sheetnames

if lfnu==1&&lsnu==1                             % Only one file and sheet, use file name only.
    out_dirs=out_dir_table(:,1);
elseif lfnu==1&&lsnu>1                          % One fname, multiple sheets, use sheet names.
    out_dirs=out_dir_table(:,2);
elseif lfnu>1&&lfnu==height(out_dir_table)      % Multiple fnames, each single sheet, use fname.
    out_dirs=out_dir_table(:,1);
elseif lfnu>1&&lfnu<height(out_dir_table)&&lsnu>1      % Multiple fnames, multiple sheets, concatenate.
    for j=1:height(out_dir_table)
        tmp=strcat(out_dir_table{j,1}, '_', out_dir_table{j,2});
    end
    out_dirs=tmp;
    clear tmp
end

% Set up for postage stamp isobolograms. Max 24/page
close all;
nf=height(out_dirs);    % number of analyses
ps_rows=5;              % Number of postage stamp rows
ps_cols=4;               % Number of postage stamp cols
ps_plts=ps_rows*ps_cols;% Number of postage stamp subplots/page
np=ceil(nf/ps_plts);  % nuber of pages % x2: Row v Col and Col v Row
for i=1:np
    figure('units','inches','position',[0.5 0.5 7.5 10.5]);
end

for iout=1:height(out_dirs)
   % before next cycle close open figs except fig 1
   for i=16:-1:np+1 % close all except the global postage stamp
       evalstr=['close ' int2str(i)];
        try
            eval(evalstr);
        end
   end
    % For each out_dir_table entry
    clear A B C D E F G H;
    % close all;
    fname=string(out_dir_table{iout,1});
    sname=string(out_dir_table{iout,2});
    out_dir=char(string(out_dirs{iout,1}));
    [rawdata,txt] = xlsread(fname, sname);   % Read data

    r_label=txt{1};             % row label
    c_label=txt{2};             % column label
    data=rawdata(2:end,2:end);  % Extract data.
    r_conc=rawdata(2:end,1);    % Extract row concentrations.
    c_conc=rawdata(1,2:end);    % extract column concentrations.
    % clear rawdata;

    fprintf('%s\n',['out_dir = ' out_dir]);

%% Part 1: Fit data and prepare plots 
    [A, B, Iso]=B_Fit_Main2(data,r_conc,c_conc, r_label, c_label, out_dir);
    if isfield(A,'err')==0
        C_plot_fits2(A); 
        print([out_dir,'\Fig3; Raw Column Data Fits.pdf'],'-dpdf','-fillpage');
    end
    if isfield(B,'err')==0
        C_plot_fits2(B);
        print([out_dir,'\Fig4; Raw Row Data Fits.pdf'],'-dpdf','-fillpage');
    end
    % clear tmp rawdata data r_conc  c_conc r_label c_label
        
    %% Print output table
    % First do A ....
    if isfield(A,'err')==0
        D_printAfit(A,out_dir);
    end

   %% Now do same thing for row-wise fits
   if isfield(B,'err')==0
        D_printAfit(B,out_dir);
   end

    %% Part 2A: Fit the MIC vs MIC profiles and plot and print the results
    try
        ic=A.ic;
    catch
        ic=[]
    end

    try
        ir=B.ic;
    catch
        ir=[];
    end

    icr=[ic ir];

    if length(icr)>=6
        C = C_Fit_all_MIC(A,B);
        E_printCfit(C);
        sgtitle('Fig 5; Fit of x-y Data to Mdl1 (n=1) and Mdl2 (n variable)', ...
            'Interpreter','none');
        print([out_dir, ...
            '\Fig5; Fit of x-y Data to Mdl1 (n=1) and Mdl2 (n variable).pdf'], ...
            '-dpdf','-fillpage');
        D=C_Fit_all_MIC(B,A);
        E_printCfit(D);
        sgtitle('Fig 6; Fit of y-x Data to Mdl1 (n=1) and Mdl2 (n variable)', ...
            'Interpreter','none');
        print([out_dir, ...
            '\Fig6; Fit of y-x Data to Mdl1 (n=1) and Mdl2 (n variable).pdf'],...
            '-dpdf','-fillpage');
    end

    % Print corresponding reports
    if exist('C','var')==1
        F_printCrpt(C,out_dir);
    end
    if exist('D','var')==1
        F_printCrpt(D,out_dir);
    end


    %% Part 2B: Generate normalized isobologram and normalized col/row summaries. 
    if exist('C','var')&&exist('D','var')       % Need both x and y fit results
        [Eopt,E1,E2]=G_printCD_4(C,D,out_dir);  % Eopt is F-test best Mdl1 (n=1) or Mdl2 (n var) fit x and y models.
                                                % E1 are Mdl1 values for both. E2 are Mdl2 values for both.
    end

   %% Part 3: 2D Fit
   try
      if exist('Eopt','var')&&length(Eopt.nx_MICs)>8; % Need enough data to fit
          F=H_fit_2D(Eopt, out_dir);
      else
          fprintf('%s\n',['No part 3 fit for out_dir = ' out_dir]);
          fprintf('%s\n',['Eopt exists? ' num2str(exist('Eopt','var'))])
          fprintf('%s\n',['Length MIC data? ' num2str(length(Eopt.nx_MICs))])
          pause
      end
   end

 %% Make postage stamp plots: Col vs Row 
   cpage = floor((iout-1)/ps_plts)+1;
   csubplot = iout-(cpage-1)*ps_plts;
   figure(cpage);   %figure(2*cpage-1) for two plots   % Col vs Row
   subplot(ps_rows,ps_cols,csubplot)
   hold off;
   if isfield(A,'ic'), plot(A.c_concic, A.Kf,'.r','MarkerSize',15); end
   hold on;
   if isfield(B,'ic'), plot(B.Kf,B.c_concic,'.b','MarkerSize',15); end
%   [m n] = size(Iso.rvc);
%   if m>0 plot(Iso.rvc(:,2),Iso.rvc(:,1),'.-g','MarkerSize',15); end
   hold off;
   if isfield(A,'c_root')&&isfield(B,'c_root')
       t_text=([A.c_root ' vs ' B.c_root]);
   elseif isfield(A,'c_root') 
       t_text=(['Col Only: ' A.c_root ' vs ' A.r_root]);
   elseif isfield(B,'c_root')
       t_text=(['Row Only: ' B.r_root ' vs ' B.c_root]);
   else
       t_text=('No Fit Result');
   end
   title(t_text);

   xlabel(['MIC_', c_label],'Interpreter','none');
   ylabel(['MIC_', r_label],'Interpreter','none');
   ylim([0 Inf]);
   xlim([0 Inf]);
    % Build legend string array
    if csubplot==1
        leg_str=[];
        if isfield(A,'ic'),leg_str=[leg_str; "Column fits"]; end
        if isfield(B,'ic'),leg_str=[leg_str,"Row Fits"]; end
%        if m>0,leg_str=[leg_str,"Simple Isobologram"]; end
        lgd=legend(leg_str,'FontSize',6,'BackgroundAlpha',0.3);
        lgd.BackgroundAlpha = .5;
    end

   % figure(2*cpage)      % Row vs Col
   % subplot(6,4,csubplot)
   % hold off;
   % if isfield(A,'ic'), plot(A.Kf, A.c_concic, '.-r','MarkerSize',20); end
   % hold on;
   % if isfield(B,'ic'), plot(B.c_concic, B.Kf, '.-b','MarkerSize',20); end
   % [m n] = size(Iso.rvc);
   % if m>0 plot(Iso.rvc(:,1), Iso.rvc(:,2),'.-g','MarkerSize',20); end
   % hold off;
   % if isfield(A,'c_root')&&isfield(B,'c_root')
   %     t_text=([A.r_root ' vs ' B.r_root]);
   % elseif isfield(A,'c_root') 
   %     t_text=(['Col Only: ' A.r_root ' vs ' A.c_root]);
   % elseif isfield(B,'c_root')
   %     t_text=(['Row Only: ' B.c_root ' vs ' B.r_root]);
   % else
   %     t_text=('No Fit Result');
   % end
   % title(t_text)
   % xlabel(['MIC_', r_label],'Interpreter','none');
   % ylabel(['MIC_', c_label],'Interpreter','none');
   % ylim([0 Inf]);
   % xlim([0 Inf]);
   % if csubplot==1
   %      legend(leg_str,'FontSize',3);
   % end
    
end

% Print postage stamp global figures
for i=1:np
    figure(i)
    sgtitle(['Isobolograms: Page ' int2str(i)],'FontSize', 16);
    print(['0_Postage Stamp Page_' int2str(i) '_CvR.pdf'],'-dpdf','-fillpage');
end
