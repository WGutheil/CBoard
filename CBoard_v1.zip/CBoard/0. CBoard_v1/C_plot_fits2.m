function [] = plot_fits2(E)
%UNTITLED2 Plot of col/row data for MICs
%   Detailed explanation goes here
    [r_conc I]=sort(E.r_conc);
    c_concic=E.c_concic;
    pred=E.pred(I,:);
    resid=E.resid(I,:);
    dataic=E.dataic(I,:);
    max_all=max([max(dataic(:)),max(resid(:)),max(pred(:))]);
    min_all=min([min(dataic(:)),min(resid(:)),min(pred(:))]);

    [xticklabels, xticks]=mk_ticklabels(r_conc);
    % [yticklabels, yticks]=mk_ticklabels(D.r_conc);
    xblankticks= [0 1];
    xblanklabels= {'' ''};
    
    % set(gca, 'XTick', xblankticks, 'XTickLabel', xblanklabels);
    % set(gca, 'YTick', yticks, 'YTickLabel', yticklabels);
    
    lc=length(E.ic);
    rc=ceil(sqrt(lc));
    cc=ceil(lc/rc);
    mc=[1:rc*cc];
    rmc=reshape(mc,[cc rc])';
    
    figure('units','inches','position',[1 0.5 7 9.5]);
    if inputname(1)=='A'
        sgtitle('Fig 3; Raw Column Data Fits');
    elseif inputname(1)=='B'
        sgtitle('Fig 4; Raw Row Data Fits');
    end
    
    for ij=1:lc
        subplot(rc,cc,rmc(ij));
        plot(dataic(:,ij),'.','MarkerSize', 20)
        hold on
        plot(pred(:,ij))
        plot(resid(:,ij),'.','MarkerSize', 20)
        set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
        title([E.c_label ' = ' num2str(c_concic(ij))],'Interpreter','none');
        xlabel(['--- ' E.r_label ' ---'],'Interpreter','none');
        ylim([min_all max_all]);
        plot([xlim],[0 0],'-k')
        if ij==lc
           lgd=legend({'data' 'predicted' 'residual'},'Location','west');
           lgd.BackgroundAlpha = .6;
        end
        hold off
    end

end