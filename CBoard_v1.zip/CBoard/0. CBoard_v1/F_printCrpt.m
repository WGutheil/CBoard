function [] = F_printCrpt(C,out_dir)
%UNTITLED Print report on col (x v y) fit
%   Detailed explanation goes here
    if inputname(1)=='C'
        Ftitle='Column';
        i_title='Rpt3;';
    elseif inputname(1)=='D'
        Ftitle='Row';
        i_title='Rpt4;';
    end

    foutname=[out_dir '\' i_title ' ' Ftitle 'MIC Fit.txt'];
    f_id=fopen(foutname,'w');
    fprintf(f_id,'%s\n\n',[i_title ' ' Ftitle ' MIC Fit Results']);
    Z=C; % Temp
    str_out={
        ['Mdl1: n=1 (Fixed)'];
        ['MIC0_' Z.y_root ' = ', num2str(Z.MIC01,3), '; se = ', num2str(Z.se_MIC01,2), '; %re = ', num2str(100*Z.se_MIC02/Z.MIC02,2), '%']; ...
        ['K_' Z.x_root '  =   ', num2str(Z.Kd1,3),   '; se = ', num2str(Z.se_Kd1,2),   '; %re = ', num2str(100*Z.se_Kd2/Z.Kd2,2), '%']; ...
        ['n_' Z.x_root ' =    ', num2str(Z.n1,3),    '; se = ', num2str(Z.se_n1,2),    ' (fixed);'];
        ['rss1 = ' num2str(C.rss1,3) ' ; df1 = ' num2str(C.df1)];
        [' '];
        ['Correlation Matrix Mdl1 (if identity then an error in calculating)'];
        [formattedDisplayText(Z.corr1,'SuppressMarkup',true,'NumericFormat','shortG')];
        ['Mdl2: n variable'];
        ['MIC0_' Z.y_root ' = ', num2str(Z.MIC02,3), '; se = ', num2str(Z.se_MIC02,2), '; %re = ', num2str(100*Z.se_MIC02/Z.MIC02,2), '%']; ...
        ['K_' Z.x_root '  =   ', num2str(Z.Kd2,3),   '; se = ', num2str(Z.se_Kd2,2),   '; %re = ', num2str(100*Z.se_Kd2/Z.Kd2,2), '%']; ...
        ['n_' Z.x_root ' =    ', num2str(Z.n2,3),    '; se = ', num2str(Z.se_n2,2),    '; %re = ', num2str(100*Z.se_n2/Z.n2,2), '%']; ...
        ['rss2 = ' num2str(C.rss2,3) ' ; df2 = ' num2str(C.df2)]; ...
        [' ']; ...
        ['Correlation Matrix Mdl2  (if identity then an error in calculating)']; ...
        [formattedDisplayText(Z.corr2,'SuppressMarkup',true,'NumericFormat','shortG')]; ...
        [' '];
        ['MDL1 (n fixed) vs MDL2 (n variable)']; ...
        ['Fstat = ' num2str(C.Fstat,3) ' ; p_val = ' num2str(C.pF,2)]};

    for i=1:length(str_out)
       fprintf(f_id,'%s\n',str_out{i,:}); % Print output
    end

    % Reprint stat test summary
    % str_out={['MDL1 (n fixed) vs MDL2 (n variable)']; ...
    %          ['Fstat = ' num2str(C.Fstat,3) ' ; p_val = ' num2str(C.pF,2)]};
    % text(0.05,0.5,str_out,'normalize','Interpreter','none');

    if Z.pF<=0.05
        str_out={['Since p_val (' num2str(Z.pF,2) ') < 0.05 then n IS statistically']; ...
                 ['different than 0.']};
    else
         str_out={['Since p_val (' num2str(Z.pF,2) ')>=0.05 then n IS NOT statistically']; ...
                  ['different than 0.']};
    end
    for i=1:length(str_out)
       fprintf(f_id,'%s\n',str_out{i,:}); % Print output
    end
    
    % text(0.05,0.3,str_out,'normalize','Interpreter','none'); 
       
    % Print obs pred resid results
    fprintf(f_id,'\n\n%s\n\n',['MIC, Obs, Predicted, Residuals']); % Print header
    clear tmp;
    tmp=table(Z.x_MICs', Z.y_MICs',Z.pred1',Z.resid1',Z.pred2',Z.resid2');
    tmp.Properties.VariableNames={['x_' Z.x_label] ['MIC_' Z.y_label] 'Pred_Mdl1' 'Resid_Mdl1' 'Pred_Mdl2' 'Resid_Mdl2'};
    str=formattedDisplayText(tmp,'SuppressMarkup',true,'NumericFormat','shortG');
    fprintf(f_id,str);
    fclose(f_id);
    
end