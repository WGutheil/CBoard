set(groot,'defaultAxesBox', 'off')
set(groot,'defaultLineLineWidth',1)
set(groot,'defaultAxesLineWidth', 1)
% set(groot,'defaultAxesTickDir', 'out')
set(groot,'defaultAxesTickLength',[0.02 0.02]);
set(groot,'defaultAxesFontSize',9)
set(groot,'defaultAxesFontName','Arial')
% set(groot,'defaultAxesTitleFontSizeMultiplier', 1.2)
set(groot,'defaultAxesFontweight','bold')
% set(groot,'defaultAxesYMinorTick', 'off')
% set(groot,'defaultAxesXMinorTick', 'off')
% set(groot,'defaultAxesXAxisLocation','bottom');
% set(groot,'defaultAxesYAxisLocation','left');
% set(groot,'defaultFigureColor',[1 1 1])