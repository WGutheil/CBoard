function [y] = FICI_func(x,k,n)
% Simple hill fnc y=1/(1+(x/k)^n), array x, scalar k and n
%   Detailed explanation goes here
    y=zeros(size(x)); % make  y match x
    for i=1:length(x(:))
        y(i) = (1 / (1 + (x(i) / k)^n)) + x; % This is the FICI function
    end

end