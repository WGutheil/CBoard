function [z_out] = zout(x_res)
%zmad MAD based z-scored function for outlier identification
%   Input residuals or other set of values for outlier detection. Used the
%   MAD approach: https://en.wikipedia.org/wiki/Median_absolute_deviation
%

z_score=(x_res-mean(x_res))/std(x_res);
z_p = 1-normcdf(abs(z_score));
z_out = z_p<0.00135; % 3 sigma

end