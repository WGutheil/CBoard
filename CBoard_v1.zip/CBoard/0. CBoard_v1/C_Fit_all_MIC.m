function [C] = C_Fit_MIC(A,B)
%UNTITLED Fit of all MIC data to hill function
%   Detailed explanation goes here

% Extract "MICs" from A and B
    try
        ic=A.ic;
    catch
        ic=[];
    end

    try
        ir=B.ic;
    catch
        ir=[];
    end

if length(ic)>0
    c_concic=A.c_concic;
    c_MICs=A.Kf;
else
    c_concic=[];
    c_MICs=[];
end

if length(ir)>0
    r_concic=B.c_concic;
    r_MICs=B.Kf;
else
    r_concic=[];
    r_MICs=[];
end

% Combine to x_MICs and y_MICs
x_MICs=[c_concic r_MICs];
y_MICs=[c_MICs r_concic];

% sort from low x_MIC to high x_MIC
[M,I]=sort(x_MICs);
x_MICs=M;
y_MICs=y_MICs(I);
clear M I;

% Find midpoint initial K estimate
min_y=min(y_MICs);
max_y=max(y_MICs);
[M,I]= min(abs(y_MICs-0.5*max(y_MICs)));
Kd1=0.5*y_MICs(I);
MIC0=max(y_MICs);

%% Set up for fit with n fixed.
n=1.0;
xc=x_MICs';
g=fittype("MIC0*(1/(1 + (xc/Kd)^n))", ...
    'problem',{'n'},...
    independent="xc");
y=y_MICs';
    [fo,gof]=fit(xc,y,g,...  
        'Lower',[0,0],...
        'problem', {n},...
        'startpoint', [Kd1 MIC0]); 
    tmp=coeffvalues(fo); 
    Kd1=tmp(1);
    MIC01=tmp(2);
    rss1=gof.sse;
    df1=gof.dfe;
    clear tmp;
    % % Get fit value
    % hold off;
    % plot(x,y)
    % hold on;
    % plot(fo);
    % hold off

%% Now fit using fminunc fitting: Works best - use
options=optimoptions('fminunc');
% options.MaxIterations=10000;
options.MaxFunctionEvaluations=200000;
options.StepTolerance=1e-7;
% options.HessianApproximation='dfp';
% options.Display='iter';

%% Redo fit with n=1
clear x x0
x0(1)=MIC01;
x0(2)=Kd1;

f=@(x)Ca_all_MIC_fit_func(x,x_MICs,y_MICs);   % fit func
[x,fval,exitf,output,grad,hessian]=fminunc(f,x0,options); % fit
MIC01=x(1);
Kd1=x(2);
df1=length(x_MICs)-length(x);          % degrees of freedom
se1=sqrt(abs(diag(pinv(hessian))*(fval/df1))); % se calc
se_MIC01=se1(1);
se_Kd1=se1(2);

try
    cor1=corrcov(pinv(hessian));   % correlation matrix
catch
    cor1=eye(length(se1));
    fprintf('%s\n', ['Corr matrix calculation error for Mdl_1 in ' A.r_label '_v_' A.c_label]);
    fprintf('%s\n',['Setting to identity matrix. Press return to continue']);
    % pause
end

[rss1, y_est1, resid1]=Ca_all_MIC_fit_func(x,x_MICs,y_MICs);

% figure
% plot(x_MICs,y_MICs,'.','MarkerSize',20)
% hold on
% plot(x_MICs,y_est1,'o','MarkerSize',6)
% plot(x_MICs,resid1,'.','MarkerSize',20)
% plot(xlim,[0,0],'-k')
% hold off
% legend({'data' 'fit' 'resid'})

%% Then with n variable
x0=x;  % Start with n=1 fixed fit
x0(3)=1; % initial n value

f=@(x)Ca_all_MIC_fit_func(x,x_MICs,y_MICs);   % fit func
[x,fval,exitf,output,grad,hessian]=fminunc(f,x0,options); % Do fit
MIC02=x(1);
Kd2=x(2);
n2=x(3);

df2=length(x_MICs)-length(x);          % degrees of freedom
se2=sqrt(abs(diag(pinv(hessian))*(fval/df2))); % se calc
se_MIC02=se2(1);
se_Kd2=se2(2);
se_n2=se2(3);

try
    cor2=corrcov(pinv(hessian));   % correlation matrix
catch
    cor2=eye(length(se2));
    fprintf('%s\n', ['Corr matrix calculation error for Mdl_2 in ' A.r_label '_v_' A.c_label]);
    fprintf('%s\n',['Setting to identity matrix.']);
end

[rss2, y_est2, resid2]=Ca_all_MIC_fit_func(x,x_MICs,y_MICs);

%% F-Test between n=1 n variable models

Fstat= ((rss1-rss2)/(df1-df2))/(rss1/df1);
pF=1-fcdf(Fstat,df1-df2,df1);

%% Prepare return information
C.x_label=A.c_label;
try, C.x_root=A.c_root; end
C.y_label=A.r_label;
try, C.y_root=A.r_root; end
C.x_MICs=x_MICs;
C.y_MICs=y_MICs;

C.Kd1=Kd1;
C.se_Kd1=se_Kd1;
C.MIC01=MIC01;
C.se_MIC01=se_MIC01;
C.n1=1;
C.se_n1=0;
C.pred1=y_est1;
C.resid1=resid1;
[~,~, C.outlier1]=zout(C.resid1);
C.rss1=rss1;
C.df1=df1;
C.corr1=cor1;

C.Kd2=Kd2;
C.se_Kd2=se2(2);
C.MIC02=x(1);
C.se_MIC02=se2(1);
C.n2=x(3);
C.se_n2=se2(3);
C.pred2=y_est2;
C.resid2=resid2;
[~,~, C.outlier2]=zout(C.resid2);
C.corr2=cor2;
C.rss2=rss2;
C.df2=df2;
C.Fstat=Fstat;
C.pF=pF;
end