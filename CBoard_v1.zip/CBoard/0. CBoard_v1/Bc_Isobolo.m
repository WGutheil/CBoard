function [Iso] = Isobolo(data,r_conc,c_conc,Alow, Ahigh)
%Isobolo This function takes checkerboard antibacterial activity data and
% extracts isobologram information from it. 
%   Detailed explanation goes here
Amid=(Ahigh+Alow)/2;

if Amid<=Alow              % Then low (Ab) gives high value, vice vers
    idata=data<=Amid;        % Index all no growth (high ab) cells
else
    idata=data>Amid;         % other way.
end
[ia,ib]=size(idata);
idata(ia+1,ib+1)=0;   % Pad bottom and right w zero. 
                        % This requires high Ab at top left
for j=1:ib
    for i=1:ia
        if isequal(idata(i:i+1,j:j+1),[1 0; 0 0]) % A corner search! 
            %   Need a different matrix for different dilution schemes!
            iidata(i,j)=1; % This ends up with ones in each "corner"
        else
            iidata(i,j)=0;
        end
    end
end
[ia, ib]=find(iidata);
Iso.rvc=[r_conc(ia) c_conc(ib)']; % Row vs column values
% figure
% subplot(1,2,1)
% plot(rvcIso(:,1),rvcIso(:,2),'-*');

irz=find(Iso.rvc(:,1)==0);
icz=find(Iso.rvc(:,2)==0);
Iso.r_MIC0=Iso.rvc(icz,1);
Iso.c_MIC0=Iso.rvc(irz,2);
Iso.rvc_norm=Iso.rvc./[Iso.r_MIC0 Iso.c_MIC0];

% Calculate Iso FIC
[Iso.dataFICI Iso.FICI_id] = min(sum(Iso.rvc_norm')); % Calc and find min dataFIC (FICI)
[Iso.FIC_RowCol]=Iso.rvc_norm(Iso.FICI_id,:);  % Row and column FICs 

% subplot(1,2,2)
% plot(rvcIso_norm(:,1),rvcIso_norm(:,2),'-*');

end