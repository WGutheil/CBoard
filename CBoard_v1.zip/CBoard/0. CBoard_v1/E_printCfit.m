function [C] = D_printCfit(C)
%UNTITLED Summary of this function goes here
%  Detailed explanation goes here

    if inputname(1)=='C'
        Ftitle=[C.x_root ' vs ' C.y_root];
    elseif inputname(1)=='D'
        Ftitle=[C.y_root ' vs ' C.x_root];
    end
% Ftitle='Column'; 
    % fprintf(Ftitle)
    figure('units','inches','position',[1 0.5 7 9.5]);
%% Panel 1
    subplot(3,2,1);
    plot(C.x_MICs,C.y_MICs,'o','MarkerSize', 6,'DisplayName', 'data');
    hold on;
    plot(C.x_MICs,C.pred1,'.-','MarkerSize',15,'DisplayName', 'pred');
    plot(C.x_MICs,C.resid1,'.','MarkerSize', 15,'DisplayName', 'resid'); 
    if sum(C.outlier1)>0
        plot(C.x_MICs(C.outlier1),C.resid1(C.outlier1),'sr','MarkerSize', 10, ...
            'DisplayName', 'outlier');
    end
    lgd=legend('AutoUpdate','off');
    lgd.BackgroundAlpha = .6;
    plot(xlim,[0 0],'-k','LineWidth',0.7);
    hold off
    xlabel(strcat('MIC_',C.x_label),'Interpreter','none');
    ylabel(strcat('MIC_',C.y_label),'Interpreter','none');
    title(['A. ' Ftitle ' Mdl_1 (n=1) Fits ' ],'Interpreter','none');

%% Panel 2    
    % MDL_2
    subplot(3,2,2);
    plot(C.x_MICs,C.y_MICs,'o','MarkerSize', 6,'DisplayName', 'data');
    hold on;
    plot(C.x_MICs,C.pred2,'.-','MarkerSize',15,'DisplayName', 'pred');
    plot(C.x_MICs,C.resid2,'.','MarkerSize', 15,'DisplayName', 'resid');
    if sum(C.outlier2)>0
        plot(C.x_MICs(C.outlier2),C.resid2(C.outlier2),'sr','MarkerSize', 10, ...
            'DisplayName', 'outlier');
        leg_str={'Data' 'Fit' 'Residuals' 'Outlier'};
    end
    lgd=legend('AutoUpdate','off');
    lgd.BackgroundAlpha = .6;
    plot(xlim,[0 0],'-k','LineWidth',0.7);
    hold off
    xlabel(strcat('MIC_',C.x_label),'Interpreter','none');
    ylabel(strcat('MIC_',C.y_label),'Interpreter','none');
    title(['B. ' Ftitle ' Mdl_2 (n variable) Fits ' ],'Interpreter','none')
%% Panel 3
    subplot(3,2,3);    
    str_out={['Mdl_1 Fit (n fixed at a value of 1):'];
             ['y = MIC0_y/(1+(x/K_x)^n_x)']; ...
             ['MIC0_' C.y_root ' = ', num2str(C.MIC01,3), '; se = ', num2str(C.se_MIC01,2)]; ...
             ['K_' C.x_root '     =  ', num2str(C.Kd1,3), '; se = ', num2str(C.se_Kd1,2)]; ...
             ['n_' C.x_root '      =   ', num2str(C.n1,3), '; se = ', num2str(C.se_n1,2) ' (fixed)'];...
             ['rss1 = ' num2str(C.rss1,3) ' ; df1 = ' num2str(C.df1)]};
    xticks([]);
    yticks([]);
    text(0.05,0.7,str_out,'normalize','Interpreter','none','FontSize', 8);
    title(['C. ' Ftitle ' Mdl_1 Fit Summary'],'Interpreter','none')    
%% Panel 4
    subplot(3,2,4);
    str_out={['Mdl_2 Fit with n variable:']; ...
             ['y = MIC0_y/(1+(x/K_x)^n_x)']; ...
             ['MIC0_' C.y_root ' = ', num2str(C.MIC02,3), '; se = ', num2str(C.se_MIC02,2)]; ...
             ['K_' C.x_root '     =  ', num2str(C.Kd2,3), '; se = ', num2str(C.se_Kd2,2)]; ...
             ['n_' C.x_root '      =   ', num2str(C.n2,3), '; se = ', num2str(C.se_n2,2)]; ...
             ['rss2 = ' num2str(C.rss2,3) ' ; df2 = ' num2str(C.df2)]};
    xticks([]);
    yticks([]);
    text(0.05,0.75,str_out,'normalize','Interpreter','none','FontSize', 8);
    title(['D. ' Ftitle ' Mdl_2 Fit Summary, and Mdl_1vMdl_2'],'Interpreter','none')

%% Mdl_1 v Mdl_2 Stats 
    str_out={['MDL_1 (n fixed) vs MDL_2 (n variable)']; ...
             ['Fstat = ' num2str(C.Fstat,3) ' ; p_val = ' num2str(C.pF,2)]};
    text(0.05,0.4,str_out,'normalize','Interpreter','none', 'FontSize', 8);
 
    if C.pF<=0.05
        str_out={['Since p_val (' num2str(C.pF,2) ') < 0.05 '];
                 ['then n IS statistically']; ...
                 ['different than 1.']};
    else
         str_out={['Since p_val (' num2str(C.pF,2) ')>=0.05 '];
                  ['then n IS NOT statistically']; ...
                  ['different than 1.']};
    end
    text(0.05,0.2,str_out,'normalize','Interpreter','none','FontSize', 8);
end