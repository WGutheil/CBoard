function [ic, Alow,Amid,Ahigh] = Ba_icolfit(data, r_conc, c_conc)
%icolfit icolfit returns the indicies of the columns in "data" that
% have a sufficient range of values between Azoro and Ahigh beyond the smallest 
% r_conc and the highest r_conc to be fit to a Hill function.
% To flip the data to do the same for rows, transpose (prime) data (data'), 
% and swap and prime r_conc and c_conc. This keeps row and column lengths
% and values consisten with data.
%   Detailed explanation goes here

[tmp,irmin]=min(r_conc); % get high and low concentration indicies
[tmp,icmin]=min(c_conc);
[tmp,irmax]=max(r_conc);
[tmp,icmax]=max(c_conc);

Alow =data(irmin,icmin); % Get absorbance or other value at the lowest antibiotic                     % concentrations.
Ahigh=data(irmax,icmax); % Get value at high ab concentrations.

Amid=(Ahigh+Alow)/2;
delt=abs(Alow-Ahigh);

% Find row indicies for columns with range greater than 0.5 of full range.
% Must exclude row with 0 concentration, since a large gap between zero A and
% all other A values provides bad K estimate.

% First select rows with r_conc~=0. This avoids problems when the zero
% conc data point is bounding the midpoint, making for poor K fits.
irnz=(r_conc~=0);

% Then select columns with >0.5 change in A value excluding r_conc==0 row.
ic=find((max(data(irnz,:))-min(data(irnz,:)))/delt>0.5);
% done

end