function [Fopt] = H_fit_2D(E,out_dir)
% Function to fit checkerboard data to bi-directional Hill function and
% prepare plots. 
% This version fits normalized values to avoid "on the fly" normalization
% in the fitting function. Builds on prior un-normalized fit, so
% un-normalized names used still for normalized variables and data.
% x is current "normallized" parameter estimates 
% nx_MIC0 = 1, ny_MIC0 = 1, nx_k, ny_k, x_n, y_n).
% if x is only 4 values long uses value of 1 for x_n and y_n.

F.x_label=E.x_label;
F.y_label=E.y_label;
F.x_root=E.x_root;
F.y_root=E.y_root;

% Extract initial variables  
x_n=E.x_n;          % col fit n
y_n=E.y_n;          % row fit n
x_k=E.nx_K;         % normalized col fit k
y_k=E.ny_K;         % normalized row fit k
x_FIC0=1;           % Initial value
y_FIC0=1;           % Initial value
x_MIC0=E.x_MIC0;    % Initial value
y_MIC0=E.y_MIC0;    % Initial value

% Extract data
% x_MICs=E.nx_MICs;
% y_FICs=E.ny_MICs;
x_MICs=E.x_MICs;        
y_MICs=E.y_MICs;

% F.x_MICs=x_MICs;    % Record data into results structure
% F.y_FICs=y_FICs;
F.x_MICs=x_MICs;
F.y_MICs=y_MICs;


clear x0;

% Initialize variables
x0(1)=x_FIC0;
x0(2)=y_FIC0;
x0(3)=x_k;
x0(4)=y_k;
x0(5)=x_n;
x0(6)=y_n;
x_ori=x0;
se0=[0 0 E.se_nx_K E.se_ny_K E.se_x_n E.se_y_n];
F.x0=x0;
F.se0=se0;

% Define var names (DIfferent than for A B C D arrays where each parameter
% value was defined and valued individually.
xnames{1}='x_FIC0'; % Normalized MIC0
xnames{2}='y_FIC0';
xnames{3}='x_k';
xnames{4}='y_k';
xnames{5}='x_n';
xnames{6}='y_n';

F.xnames=xnames;
F.x_Mdl_opt=E.x_Mdl(5); % Get ID number best x mdl
F.y_Mdl_opt=E.y_Mdl(5); % Get ID number best y mdl

% Get mean FICI
% F.x_fitFICI = E.x_fitFICI;
% F.y_fitFICI = E.y_fitFICI;
% F.mean_FICI = (F.x_fitFICI + F.y_fitFICI)/2;

%% Setup fit using fminunc fitting:
opt_unc=optimoptions(@fminunc);
opt_unc.Display='none';
opt_unc.FiniteDifferenceType='central';
opt_unc.MaxFunctionEvaluations=20000;
opt_unc.MaxIterations=20000;

opt_con=optimoptions(@fmincon);
opt_con.Display='none';
opt_con.FiniteDifferenceType='central';
opt_con.MaxFunctionEvaluations=20000;
opt_con.MaxIterations=20000;


% lb and ub for contrained
lbcon = [0.8 0.8 0.0002 0.0002 0.1 0.1]; % [FIC0_x FIC0_y k_x k_y n_x n_y]
ubcon = [1.2 1.2 2 2 Inf Inf];

%% Fitting to 2D Mdl's

% For the bi-fit approach need to calculate the n value in the function 
% x^n + y^n = 1 that passes through or near the FICI point of the equilibrium/Hill
% function x (col) and y (row) fits. Formula is n = log(1/2)/log(FICI/2)
% n_FICI=log(1/2)/log(E.avgFICI/2);
% F.n_FICI=n_FICI;

% Better yet, find n to give a y=0.5 at mean_FICI_x. 
% Use fminunc to find answer
fun=@(n)(abs((E.avgFICI/2)^n + 0.5^n - 1));
n_FICI=fminunc(fun,.2);
% n_FICI=1; % For testing

% To plot this curve over data
% figure
% p=[0:0.01:1];
% q=(1-p.^n_FICI).^(1/n_FICI);
% plot(p,q);
% hold on
% plot(p,1-q);
% plot([0 E.avgFICI/2 E.avgFICI/2],[E.avgFICI/2 E.avgFICI/2 0]);
% plot(x_MICs,y_FICs,'.', MarkerSize=20);
% title(['x^n + y^n = 1 curve with n = ' num2str(n_FICI,3)]);
% legend({'x^n + y^n = 1 curve' 'complimentary curve' 'mean FIC_x_y values' 'Data'});
% hold off

%% Set up to make tables
vx_names_t=[{'rss'} F.xnames {'avgmin_x_FIC' 'avgmin_y_FIC' 'avgmin_FICI'}]';               % Variable Names
corx_names = {'x_FIC0|MIC0' 'y_FIC0|MIC0' 'x_k|K' 'y_k|K' 'x_n' 'y_n'}; % Correlation names
corr_names=replace(corx_names,'x',F.x_root);
corr_names=replace(corr_names,'y',F.y_root); % Correlations are not concentration unit dependent


%% Get initial FICs and FICI values from part2 minimal mdl from bi-model
x_MIC0_00=x_MIC0;
y_MIC0_00=y_MIC0;
[rss0, rss_y0, rss_x0, y_pred0, x_pred0, resid_y0, resid_x0]= ...
    Hd_MIC_2D_un_norm_fit_func_renorm_2(x0, x_MICs./x_MIC0, y_MICs./y_MIC0, n_FICI);   % Initial Values. FICs calc on fly
% F.rss0=rss0;
x=E.x_fitFIC_x; % Initial x_FICmin estimate from 1D fits (Part II). Can just guess also
allFIC_00=Hc_getFIC_I(x,x0,n_FICI); % Returns a table of all FICx,y,x+y values 
                                    % from x-dim and y-dim fits and their averages and se's

%% Fit to Mdl_11; Fixed n_x and n_y = 1
x_MIC0_11=x_MIC0;
y_MIC0_11=y_MIC0;

% Fit first with constrained
fun=@(x)Hd_MIC_2D_un_norm_fit_func_renorm_2(x,x_MICs/x_MIC0_11, y_MICs/y_MIC0_11,n_FICI);   % 2D fit function
[x11,rss11,exitf11,output11,grad11,hessian11]=fmincon(fun,x0(1:4),[],[],[],[],lbcon(1:4),ubcon(1:4),[],opt_con);

% Fix MIC0s
x_MIC0_11=x_MIC0_11*x11(1);
y_MIC0_11=y_MIC0_11*x11(2);

% Refit with unconstrained
fun=@(x)Hd_MIC_2D_un_norm_fit_func_renorm_2(x,x_MICs/x_MIC0_11, y_MICs/y_MIC0_11,n_FICI);   % 2D fit function
[x11,rss11,exitf11,output11,grad11,hessian11]= ...
    fminunc(fun,x11,opt_unc); % fit of x0 1-4, ns = 1

% Fix MIC0s
x_MIC0_11=x_MIC0_11*x11(1);
y_MIC0_11=y_MIC0_11*x11(2);

% Finish
[rss11, rss_y11, rss_x11, y_pred11, x_pred11, resid_y11, resid_x11]= ...
    Hd_MIC_2D_un_norm_fit_func_renorm_2(x11, x_MICs/x_MIC0_11, y_MICs/y_MIC0_11,n_FICI); % x11 values
df11=length(x_MICs)+length(y_MICs)-length(x11);
se11=sqrt(abs(diag(pinv(hessian11))*(rss11/df11)))'; % se Mdl1:Mdl1 calc
x11=[x11 1 1];
se11=[se11 0 0];
try
    cor11=corrcov(pinv(hessian11));   % correlation matrix
catch
    cor11=eye(length(hessian11));
end

tmp=array2table(cor11);
tmp.Properties.RowNames=corr_names(1:4);
tmp.Properties.VariableNames=tmp.Properties.RowNames;

t_cor11=tmp;

% Get se for new MIC0s by propagation of errors
se_x_MIC0_11 = x_MIC0_11 * se11(1)/x11(1);
se_y_MIC0_11 = y_MIC0_11 * se11(2)/x11(2);

% Get the FICIs from this fit. ID Format: (axis value)_FICI_(fit dimension 2
% digits)(model id ##). OR FICI_(fit dimension)(models id)

x=E.x_fitFIC_x; % Initial estimate from 1D fits (Part II). Can just guess also.
allFIC_11=Hc_getFIC_I(x,x11,n_FICI);

%% Fit To Mdl_21
x_MIC0_21=x_MIC0;
y_MIC0_21=y_MIC0;

% Fit first with constrained
fun=@(x)Hd_MIC_2D_un_norm_fit_func_renorm_2(x,x_MICs/x_MIC0_21, y_MICs/y_MIC0_21,n_FICI);   % 2D fit function
[x21,rss21,exitf21,output21,grad21,hessian21]=fmincon(fun,x0(1:5),[],[],[],[],lbcon(1:5),ubcon(1:5),[],opt_con);

% Fix MIC0s
x_MIC0_21=x_MIC0_21*x21(1);
y_MIC0_21=y_MIC0_21*x21(2);

% Refit. Usually doesnt make a difference.
fun=@(x)Hd_MIC_2D_un_norm_fit_func_renorm_2(x,x_MICs/x_MIC0_21, y_MICs/y_MIC0_21,n_FICI);   % 2D fit function
[x21,rss21,exitf21,output21,grad21,hessian21]= ...
    fminunc(fun,x21,opt_unc); % fit of x0 1-5, x_n var, y_n = 1

% Fix MIC0s
x_MIC0_21=x_MIC0_21*x21(1);
y_MIC0_21=y_MIC0_21*x21(2);

[rss21, rss_y21, rss_x21, y_pred21, x_pred21, resid_y21, resid_x21]= ...
    Hd_MIC_2D_un_norm_fit_func_renorm_2(x21, x_MICs/x_MIC0_21, y_MICs/y_MIC0_21,n_FICI); % Get details

df21=length(x_MICs)+length(y_MICs)-length(x21);
se21=sqrt(abs(diag(pinv(hessian21))*(rss21/df21)))'; % se Mdl1:Mdl1 calc
x21=[x21 1];
se21=[se21 0];
try
    cor21=corrcov(pinv(hessian21));   % correlation matrix
catch
    cor21=eye(length(hessian21));
end

tmp=array2table(cor21);
tmp.Properties.RowNames=corx_names(1:5);
tmp.Properties.VariableNames=tmp.Properties.RowNames;

t_cor21=tmp;

% Get se for new MIC0s by propagation of errors
se_x_MIC0_21 = x_MIC0_21 * se21(1)/x21(1);
se_y_MIC0_21 = y_MIC0_21 * se21(2)/x21(2);

allFIC_21=Hc_getFIC_I(x,x21,n_FICI);

%% To Mdl_12
% Note: For this fit can use same "fun" but first need to swap x and y vars
% and data, redefine the fun annonymous function accordingly.
x_MIC0_12=x_MIC0;
y_MIC0_12=y_MIC0;

% Fit first with constrained. Note shuffle of x0 initial estimate
fun=@(x)Hd_MIC_2D_un_norm_fit_func_renorm_2(x,y_MICs/y_MIC0_12, x_MICs/x_MIC0_12,n_FICI);   % 2D fit function
[x12,rss12,exitf12,output12,grad12,hessian12]=fmincon(fun,x0([2 1 4 3 6]), ...
    [],[],[],[],lbcon([2 1 4 3 6]),ubcon([2 1 4 3 6]),[],opt_con);

% Fix MIC0s. Note swapped first two x12 values  ...
x_MIC0_12=x_MIC0_12*x12(2);
y_MIC0_12=y_MIC0_12*x12(1);

% Refit 
fun=@(x)Hd_MIC_2D_un_norm_fit_func_renorm_2(x, y_MICs./y_MIC0_12, x_MICs./x_MIC0_12,n_FICI);   % !!! x and y data swapped
[x12,rss12,exitf12,output12,grad12,hessian12]= ...
    fminunc(fun,x12,opt_unc); % fit of x0 1-5, y_n var, x_n = 1

% Fix MIC0s.
x_MIC0_12=x_MIC0_12*x12(2);
y_MIC0_12=y_MIC0_12*x12(1);

[rss12, rss_y12, rss_x12, y_pred12, x_pred12, resid_y12, resid_x12]= ...  % not swapped y and x indicies
    Hd_MIC_2D_un_norm_fit_func_renorm_2([x12([2 1 4 3]) 1 x12(5)], x_MICs./x_MIC0_12, y_MICs./y_MIC0_12, n_FICI); % x12 values

df12=length(x_MICs)+length(y_MICs)-length(x12);
se12=sqrt(abs(diag(pinv(hessian12))*(rss12/df12)))'; % se Mdl1:Mdl1 calc
x12=[x12([2 1 4 3]) 1 x12(5)]; % Swap values back with fixed 1 value for x(5)
se12=[se12([2 1 4 3]) 0 se12(5)];

try
    cor12=corrcov(pinv(hessian12));   % correlation matrix
catch
    cor12=eye(length(hessian12));
end
cor12=cor12([2 1 4 3 5],[2 1 4 3 5]); % Shuffle back

tmp=array2table(cor12);
tmp.Properties.RowNames=corr_names([1:4,6]);
tmp.Properties.VariableNames=tmp.Properties.RowNames;

t_cor12=tmp;

allFIC_12=Hc_getFIC_I(x,x12,n_FICI);

%% To Md22
x_MIC0_22=x_MIC0;
y_MIC0_22=y_MIC0;

% Fit first with constrained
% [x22,rss22,exitf22,output22,grad22,hessian22]=fminunc(fun,x0,options); % Fit of all x0s
fun=@(x)Hd_MIC_2D_un_norm_fit_func_renorm_2(x,x_MICs/x_MIC0_22, y_MICs/y_MIC0_22,n_FICI);   % 2D fit function
[x22,rss22,exitf22,output22,grad22,hessian22]=fmincon(fun,x0,[],[],[],[],lbcon,ubcon,[],opt_con);

% After first fit need to correct x_MICs and y_FICs and refit
x_MIC0_22=x_MIC0_22*x22(1);
y_MIC0_22=y_MIC0_22*x22(2);

% Refit
fun=@(x)Hd_MIC_2D_un_norm_fit_func_renorm_2(x,x_MICs/x_MIC0_22, y_MICs/y_MIC0_22, n_FICI);   % 2D fit function
[x22,rss22,exitf22,output22,grad22,hessian22]=fminunc(fun,x22,opt_unc);

[rss22, rss_y22, rss_x22, y_pred22, x_pred22, resid_y22, resid_x22]= ... 
    Hd_MIC_2D_un_norm_fit_func_renorm_2(x22, x_MICs/x_MIC0_22, y_MICs/y_MIC0_22, n_FICI);

df22=length(x_MICs)+length(y_MICs)-length(x22);
se22=sqrt(abs(diag(pinv(hessian22))*(rss22/df22)))'; % se Mdl2:Mdl2 calc

try
    cor22=corrcov(pinv(hessian22));   % correlation matrix
catch
    cor22=eye(length(hessian22));
end

tmp=array2table(cor22);
tmp.Properties.RowNames=corr_names;
tmp.Properties.VariableNames=tmp.Properties.RowNames;

t_cor22=tmp;

allFIC_22=Hc_getFIC_I(x,x22,n_FICI);

%% Global Results Report Output
% Prepare tables for fit values
c_names = {['M_ori_' F.x_Mdl_opt F.y_Mdl_opt]; 'Mdl_11'; 'Mdl_21'; 'Mdl_12'; 'Mdl_22'}';  % Col Names

vx_names=[{'rss'} F.xnames {'avgmin_x_FIC' 'avgmin_y_FIC' 'avgmin_FICI'}]'; % Variable x y Names
vr_names=replace(vx_names,'x', F.x_root);
vr_names=replace(vr_names,'y', F.y_root);     % Variable root substituted names

% Normalized values first
t=[rss0 x0 allFIC_00{:,3}'; ...            % Make Table
    rss11 x11 allFIC_11{:,3}'; ...
    rss21 x21 allFIC_21{:,3}'; ...   
    rss12 x12 allFIC_12{:,3}'; ...
    rss22 x22 allFIC_22{:,3}']';    
tval=array2table(t);
tval.Properties.VariableNames=c_names; % row col swap
tval.Properties.RowNames=vr_names;      % ditto
t_title=['Values of 1 for ' F.x_root '_n and ' F.y_root '_n are fixed.'];
if length(t_title)>63                   % VarName limit
    t_title=['Values of 1 for x_n and y_n are fixed'];
end
tvalt=table(tval,'VariableNames', {t_title});
tvalt=table(tvalt, 'VariableNames',{'RSS and Normalized Fit and Derived Parameter Values'});

% Tables for SEs
se_names=vr_names(2:end);
t=[se0 allFIC_00{:,4}'; ...
    se11 allFIC_11{:,4}'; ...
    se21 allFIC_21{:,4}'; ...
    se12 allFIC_12{:,4}'; ...
    se22 allFIC_22{:,4}']';
tse=array2table(t);
tse.Properties.VariableNames=c_names;
tse.Properties.RowNames=vr_names(2:end);
tset=table(tse,'VariableNames',{'SEs for normalized fit values and derived FICIs. 0s for fixed.'});

% Table for % REs
tre=array2table(100*tse{:,:}./tval{2:end,:});
tre.Properties.VariableNames=c_names;
tre.Properties.RowNames=vr_names(2:end);
tret=table(tre,'VariableNames',{'% REs for Normalized Fit and Derived Parameter Values.'});

% Then un-normalized values
vunx_names=[{'x_MIC0' 'y_MIC0' 'x_K' 'y_K'}]';
vunr_names=replace(vunx_names,'x', F.x_label);
vunr_names=replace(vunr_names,'y', F.y_label);

t=[ x_MIC0_00 y_MIC0_00  x0(3)*x_MIC0_00  x0(4)*y_MIC0_00;
    x_MIC0_11 y_MIC0_11 x11(3)*x_MIC0_11 x11(4)*y_MIC0_11; 
    x_MIC0_21 y_MIC0_21 x21(3)*x_MIC0_21 x21(4)*y_MIC0_21; 
    x_MIC0_12 y_MIC0_12 x12(3)*x_MIC0_12 x12(4)*y_MIC0_12; 
    x_MIC0_22 y_MIC0_22 x22(3)*x_MIC0_22 x22(4)*y_MIC0_22]'; 
     
tunval=array2table(t);                      % And for un-normalized
tunval.Properties.VariableNames=c_names;
tunval.Properties.RowNames=vunr_names;
tunvalt=table(tunval,'VariableNames',{'Derived un-normalized MICOs and Hill K (IC50) values'});

% MIC and K SEsa
t=[E.se_x_MIC0 E.se_y_MIC0 se0(3)*x_MIC0_00 se0(4)*y_MIC0_00;...
      se11(1)*x_MIC0_11 se11(2)*y_MIC0_11 se11(3)*x_MIC0_11 se11(4)*y_MIC0_11; ...
      se21(1)*x_MIC0_21 se21(2)*y_MIC0_21 se11(3)*x_MIC0_21 se21(4)*y_MIC0_21; ...
      se12(1)*x_MIC0_12 se12(2)*y_MIC0_12 se12(3)*x_MIC0_12 se12(4)*y_MIC0_12; ...
      se22(1)*x_MIC0_22 se22(2)*y_MIC0_22 se11(3)*x_MIC0_22 se22(4)*y_MIC0_22]';

tunse=array2table(t);                      % And for un-normalized
tunse.Properties.VariableNames=c_names;
tunse.Properties.RowNames=vunr_names;
tunset=table(tunse,'VariableNames',{'SEs for derived un-normalized MICOs and Hill K (IC50) values'});

tunre=array2table(100*tunse{:,:}./tunval{:,:});
tunre.Properties.VariableNames=c_names;
tunre.Properties.RowNames=vunr_names;
tunret=table(tunre,'VariableNames',{'% REs for derived un-normalized MICOs and Hill K (IC50) values'});

% Save
F.All_fit_vals=tval;
F.tvalt=tvalt;
F.All_fit_unvals=tunval;
F.tunvalt=tunvalt;

F.All_fit_unvals=tunval;
F.tunvalt=tunvalt;
F.All_fit_unvalses=tunse;
F.tunvalset=tunset;

%


%% Output Global Model Fitting Results
% close all
fid=[out_dir '\' 'Rpt5; BiDirectional Fit Global Model Summary.txt'];
f_id=fopen(fid,'w');
fprintf(f_id,'%s\n\n',['Rpt5; BiDirectional Fit Global Model Summary.txt']);
fprintf(f_id,'%s\n', '  Fit Model Values. M_ori_xy is the Part 2 best fit model. x and y are 1 for n=1 fixed or 2 for n variable.');
fprintf(f_id,'%s\n', '  Mdl_xy are bi-directional model fits where x and y = 1 denote n fixed at 1');
fprintf(f_id,'%s\n', '  or =2 for n variable for the x and y dimensions respectively. Values of 1 for n''s and M_ori');
fprintf(f_id,'%s\n', '  FIC0''s are fixed values.');
fprintf(f_id,'%s\n\n','');

fprintf(f_id,'%s\n\n',['BiDirectional Fit Global Model Summary']);
fprintf(f_id,'%s\n\n',formattedDisplayText(tvalt,'SuppressMarkup',true,'LineSpacing','compact'));
fprintf(f_id,'%s\n\n',formattedDisplayText(tset,'SuppressMarkup',true,'LineSpacing','compact'));
fprintf(f_id,'%s\n\n',formattedDisplayText(tret,'SuppressMarkup',true,'LineSpacing','compact','NumericFormat','bank'));

fprintf(f_id,'%s\n\n',formattedDisplayText(tunvalt,'SuppressMarkup',true,'LineSpacing','compact'));
fprintf(f_id,'%s\n\n',formattedDisplayText(tunset,'SuppressMarkup',true,'LineSpacing','compact'));
fprintf(f_id,'%s\n\n',formattedDisplayText(tunret,'SuppressMarkup',true,'LineSpacing','compact','NumericFormat','bank'));

%% F-tests
% [h,pF]=vartest2([resid_x11 resid_y11],[resid_x12 resid_y12],'Tail','right'); % Ftest on residuals, one sided
% [h,pK_11_12]=kstest2([resid_x11 resid_y11],[resid_x12 resid_y12],'Tail','smaller');% KS test on residuals, one sided
% [h,pK_11_21]=kstest2([resid_x11 resid_y11],[resid_x21 resid_y21],'Tail','smaller');% KS test on residuals, one sided

[pF_11_12, Fstat]=He_pF(rss11,rss12,df11,df12); % One sided F-test on rss values
[pF_11_21, Fstat]=He_pF(rss11,rss21,df11,df21); 
[pF_12_22, Fstat]=He_pF(rss12,rss22,df12,df22);
[pF_21_22, Fstat]=He_pF(rss21,rss22,df21,df22);
[pF_11_22, Fstat]=He_pF(rss11,rss22,df11,df22);

fprintf(f_id,'%s\n', ' F-test results between alternative models. pF_a_b, where a is id of fewer variables model');
fprintf(f_id,'%s\n\n', ' and b is id of more more variables model.');
fprintf(f_id,'%s\n', ['pF_11_12 = ' num2str(pF_11_12, 3)]);
fprintf(f_id,'%s\n', ['pF_11_21 = ' num2str(pF_11_21, 3)]);
fprintf(f_id,'%s\n', ['pF_12_22 = ' num2str(pF_12_22, 3)]);
fprintf(f_id,'%s\n', ['pF_21_22 = ' num2str(pF_21_22, 3)]);
fprintf(f_id,'%s\n', ['pF_11_22 = ' num2str(pF_11_22, 3)]);
fprintf(f_id,'%s\n', '');

% select best model
bid=[11];
co=0.05; % p value cutoff
if pF_11_12 < pF_11_21
    if pF_11_12 < co
        bid=[bid 12];
        if pF_12_22 < co
            bid=[bid 22];
        end
    end
else
    if pF_11_21 < co
        bid=[bid 21];
        if pF_21_22 < co
            bid=[bid 22];
        end
    end
end

bid=bid(end);

fprintf(f_id,'%s\n', ['The Best Bi-Directional Model (F-test @ p<0.05) is Mdl_' num2str(bid)] );
fclose(f_id);

%% Save Best Model Fit Results
% Make structures for all models
for i=[11,21,12,22]
    clear Ftmp;
    sbid=num2str(i);
    Ftmp.x_label=F.x_label;                     % Labels
    Ftmp.y_label=F.y_label;
    Ftmp.x_root=F.x_root;
    Ftmp.y_root=F.y_root;
    Ftmp.x_MICs=x_MICs;                         % Raw data
    Ftmp.y_MICs=y_MICs;
    eval(['Ftmp.x_MIC0 = x_MIC0_' sbid ';']);
    eval(['Ftmp.y_MIC0 = y_MIC0_' sbid ';']);
    Ftmp.x_FICs=Ftmp.x_MICs/Ftmp.x_MIC0;
    Ftmp.y_FICs=Ftmp.y_MICs/Ftmp.y_MIC0;
    Ftmp.Mdl = bid;                             % Best model ID
    Ftmp.vx_names=xnames;                           % Internal voutliariable names
    eval(['Ftmp.x=x' sbid ';']);                % Variable values
    eval(['Ftmp.se=se' sbid ';']);              % Variable SEs
    eval(['Ftmp.rss=rss' sbid ';']);            % Total fit RSS
    eval(['Ftmp.rss_x=rss_x' sbid ';']);        % x dim rss
    eval(['Ftmp.rss_y=rss_y' sbid ';']);        % y dim rss
    eval(['Ftmp.x_pred=x_pred' sbid ';']);        % 
    eval(['Ftmp.y_pred=y_pred' sbid ';']);
    eval(['Ftmp.x_resid=resid_x' sbid ';']);
    eval(['Ftmp.x_outlier = zpout(Ftmp.x_resid);']);
    eval(['Ftmp.y_resid=resid_y' sbid ';']);
    eval(['Ftmp.y_outlier = zpout(Ftmp.y_resid);']);
    eval(['Ftmp.df=df' sbid ';']);
    eval(['Ftmp.t_cor=t_cor' sbid ';']);
    eval(['Ftmp.allFICI=allFIC_' sbid ';']);
    eval(['Ftmp.tval = tval(2:end,''Mdl_' sbid ''');']);
    eval(['Ftmp.tse = tse(:,''Mdl_' sbid ''');']);
    eval(['Ftmp.tre = tre(:,''Mdl_' sbid ''');']);
    Ftmp.tse.Properties.VariableNames = {'SEs'};
    Ftmp.tre.Properties.VariableNames = {'%REs'};

    Ftmp.tval_se_re=[Ftmp.tval Ftmp.tse Ftmp.tre];
    Ftmp.vx_names = vx_names;
    Ftmp.vr_names = vr_names;
    Ftmp=rmfield(Ftmp,{'tval' 'tse' 'tre'});

    eval(['Ftmp.tunval = tunval(:,''Mdl_' sbid ''');']);
    eval(['Ftmp.tunse = tunse(:,''Mdl_' sbid ''');']);
    eval(['Ftmp.tunre = tunre(:,''Mdl_' sbid ''');']);
    Ftmp.tunse.Properties.VariableNames = {'SEs'};
    Ftmp.tunre.Properties.VariableNames = {'%REs'};
    Ftmp.tunval_se_re=[Ftmp.tunval Ftmp.tunse Ftmp.tunre];
    Ftmp.vunx_names=vunx_names;
    Ftmp.vunr_names=vunx_names;
    Ftmp=rmfield(Ftmp,{'tunval' 'tunse' 'tunre'});
    Ftmp.tall=[Ftmp.tval_se_re; Ftmp.tunval_se_re];
    % Reassign Fxx=Ftmp to finish
    eval(['F' sbid '= Ftmp;']);
end
clear Ftmp;
sbid=num2str(bid);
eval(['Fopt = F' sbid ';']); % Create Fopt for best model

%% Plot all models
figure('units','inches','position',[1 0.5 7 9.5]);
sgtitle(['Fig 10; All Bi-Directional Models x- and y-Dimension Fits'],'Interpreter','none');
subplot(4,2,1)
ij=0;
for i=[11 21 12 22]
    ij=ij+1;
    eval(['Ftmp = F' num2str(i) ';']);
    subplot(4,2,ij)
    plot(Ftmp.x_FICs, Ftmp.y_FICs, 'or','MarkerSize', 6,'DisplayName', 'data'); 
    hold on;
    plot(Ftmp.x_FICs, Ftmp.y_pred, '.-b','MarkerSize', 15,'DisplayName', 'pred');
    plot(Ftmp.x_FICs, Ftmp.y_resid, '.g','MarkerSize', 15,'DisplayName', 'resid');    % Residuals
    if sum(Ftmp.y_outlier)>0
      plot(Ftmp.x_FICs(Ftmp.y_outlier), Ftmp.y_resid(Ftmp.y_outlier),'sr', ...
          'MarkerSize',10,'DisplayName','outlier');
    end
    % If fit blows up then Ftmp.y_pred has length 1 amd legend then is
    % messed up. Test for and avoid
    if length(Ftmp.y_pred)==length(Ftmp.x_FICs)
        lgd=legend('AutoUpdate','off');
        lgd.BackgroundAlpha = .6;
    end
    x_lim=xlim;
    plot(x_lim, [0 0], '-k');
    xlim(x_lim);
    xlabel(['FIC_' Ftmp.x_root],'Interpreter','none');
    ylabel(['FIC_' Ftmp.y_root],'Interpreter','none');
    title(['Bi-Directional Mdl_' num2str(i) ' Fit: x-y plot'], 'Interpreter','none');
    hold off;
    clear x_lim xlim;

    ij=ij+1;
    subplot(4,2,ij)
    plot(Ftmp.y_FICs, Ftmp.x_FICs, 'or','MarkerSize', 6,'DisplayName', 'data'); 
    hold on;
    plot(Ftmp.y_FICs, Ftmp.x_pred, '.-b','MarkerSize', 15,'DisplayName', 'pred');
    plot(Ftmp.y_FICs, Ftmp.x_resid, '.g','MarkerSize', 15,'DisplayName', 'resid');    % Residuals
    if sum(Ftmp.x_outlier)>0 % Check if outliers
        plot(Ftmp.y_FICs(Ftmp.x_outlier), Ftmp.x_resid(Ftmp.x_outlier),'sr', ...
            'MarkerSize',10,'DisplayName', 'outlier');
    end
    % If fit blows up then Ftmp.x_pred has length 1 amd legend then is
    % messed up. Test for and avoid
    if length(Ftmp.x_pred)==length(Ftmp.y_FICs)
        lgd=legend('AutoUpdate','off');
        lgd.BackgroundAlpha = .6;
    end
   
    lgd=legend('AutoUpdate','off');
    lgd.BackgroundAlpha = .6;
    x_lim=xlim;
    plot(x_lim, [0 0], '-k');
    xlim(x_lim);
    xlabel(['FIC_' F.y_root],'Interpreter','none');
    ylabel(['FIC_' F.x_root],'Interpreter','none');
    title(['Bi-Directional Mdl_' num2str(i) ' Fit: y-x plot'], 'Interpreter','none');
    hold off;
    clear x_lim xlim;
end

print([out_dir, ...
            '\Fig10; All Bi-Directional Models x- and y-Dimension Fits.pdf'],...
            '-dpdf','-fillpage');


%% Plots and output - Best model
figure('units','inches','position',[1 0.5 7 9.5]);
sgtitle(['Fig 11; Best Bi-Directional Model (Mdl_' sbid ') Fit'],'Interpreter','none');

subplot(3,2,1)
plot(Fopt.x_FICs, Fopt.y_FICs, 'or','MarkerSize', 6);           % Plot Data
hold on;
plot(Fopt.x_FICs, Fopt.y_pred, '.-b','MarkerSize', 15);          % Plot fit estimates
plot(Fopt.x_FICs, Fopt.y_resid, '.g','MarkerSize', 15);    % Residuals
x_lim=xlim;
plot(x_lim, [0 0], '-k');
xlim(x_lim);
xlabel(['FIC_' F.x_root],'Interpreter','none');
ylabel(['FIC_' F.y_root],'Interpreter','none');
lgd=legend({'data' 'fit' 'resid'});
lgd.BackgroundAlpha = .6;
title(['Bi-Directional Model Fit: x-y plot'], 'Interpreter','none');
hold off;
clear xlim ylim x_lim y_lim;

subplot(3,2,2)
plot(Fopt.y_FICs, Fopt.x_FICs, 'or','MarkerSize', 6);
hold on;
plot(Fopt.y_FICs, Fopt.x_pred, '.-b','MarkerSize', 15);
plot(Fopt.y_FICs, Fopt.x_resid, '.g','MarkerSize', 15);
x_lim=xlim;
plot(x_lim, [0 0], '-k');
xlim(x_lim);

xlabel(['FIC_' E.y_root],'Interpreter','none');
ylabel(['FIC_' E.x_root],'Interpreter','none');
lgd=legend({'data' 'fit' 'resid'});
lgd.BackgroundAlpha = .6;
title('Bi-Directional Model Fit: y-x plot','Interpreter','none');
hold off;
clear xlim ylim x_lim y_lim;

subplot(3,2,3)
plot(Fopt.x_FICs, Fopt.y_FICs, 'or','MarkerSize', 7);           % Plot Data
hold on;
plot(Fopt.x_FICs, Fopt.y_pred, '.-b','MarkerSize', 15);          % Plot x fit estimates
plot(Fopt.x_pred, Fopt.y_FICs,  '.-c', 'MarkerSize', 15);        % Plot y fit estimates

plot(Fopt.x_FICs, Fopt.y_resid, '.','MarkerSize', 15);    % Residuals
plot(Fopt.x_resid, Fopt.y_FICs,  '.','MarkerSize', 15);

xlim('auto');
ylim('auto');
xlim tickaligned;
ylim tickaligned;

x_lim=xlim;
y_lim=ylim;
plot(x_lim, [0 0], '-k');
plot([0 0], y_lim, '-k');
xlim(x_lim);
ylim(y_lim);

xlabel(['FIC_' E.x_root],'Interpreter','none');
ylabel(['FIC_' E.y_root],'Interpreter','none');
lgd=legend({'data' 'x-y fit' 'y-x fit' 'x-resids' 'y-resids'});
lgd.BackgroundAlpha = .6;
title(['Bi-Directional Model Fit: x-y Overlay'], 'Interpreter','none');
hold off
clear xlim ylim x_lim y_lim;

subplot(3,2,4)
plot(Fopt.y_FICs, Fopt.x_FICs, 'or','MarkerSize', 7);           % Plot Data
hold on;
plot(Fopt.y_FICs, Fopt.x_pred, '.-b','MarkerSize', 15);          % Plot x fit estimates
plot(Fopt.y_pred, Fopt.x_FICs,  '.-c', 'MarkerSize', 15);        % Plot y fit estimates

plot(Fopt.y_FICs, Fopt.x_resid, '.','MarkerSize', 15);    % Residuals
plot(Fopt.y_resid, Fopt.x_FICs,  '.','MarkerSize', 15);

xlim('auto');
ylim('auto');
xlim tickaligned;
ylim tickaligned;

x_lim=xlim;
y_lim=ylim;
plot(x_lim, [0 0], '-k');
plot([0 0], y_lim, '-k');
xlim(x_lim);
ylim(y_lim);

xlabel(['FIC_' E.y_root],'Interpreter','none');
ylabel(['FIC_' E.x_root],'Interpreter','none');
lgd=legend({'data' 'y-x fit' 'x-y fit' 'x-resids' 'y-resids'});
lgd.BackgroundAlpha = .6;
title(['Bi-Directional Model Fit: y-x Overlay'], 'Interpreter','none');
hold off
clear xlim ylim x_lim y_lim;

subplot(3,2,5)
str_out=formattedDisplayText(Fopt.tall,'SuppressMarkup',true,'LineSpacing','compact');
% text(0.05,0.95,str_out,'FontSize', 8,'VerticalAlignment','top');
text(0.05,0.95,str_out,'Interpreter','none','FontSize', 6,'VerticalAlignment','top')
xticks([]);
yticks([]);
title('Bi-Directional Fit Summary');

% subplot(3,2,6)  % needs shrinking - correlation matrix
% % tmp=num2str(Fopt.t_cor{:,:},2);
% % clear new
% % for i=1:size(tmp)
% %     new(i,:)=split(strip(tmp(i,:)))';
% % end
% % tmp=table(new)
% % 
% % tmp.Properties.RowNames=Fopt.t_cor.Properties.RowNames;
% % tmp.Properties.VariableNames=Fopt.t_cor.Properties.RowNames;
% 
% str_out=formattedDisplayText(Fopt.t_cor,'SuppressMarkup',true,'LineSpacing','compact','NumericFormat','short');
% % text(0.05,0.95,str_out,'FontSize', 8,'VerticalAlignment','top');
% text(0.05,0.95,str_out,'Interpreter','none','FontSize', 6,'VerticalAlignment','top')
% xticks([]);
% yticks([]);
% title('Bi-Directional Fit Summary');

print([out_dir, ...
            '\Fig11; Mdl_' sbid ' Bi-Directional Model Fit.pdf'],...
            '-dpdf','-fillpage');
%% Best BiDirectional Model Fit Details Output
% close all
fid=[out_dir '\' 'Rpt6; BiDirectional Fit Best Model (Mdl_' sbid ') Detailed Model Summary.txt'];
f_id=fopen(fid,'w');
fprintf(f_id, '%s\n\n', ['Rpt6; BiDirectional Fit Best Model (Mdl_' sbid ') Detailed Model Summary.txt']);

tval_se_re_t=table(Fopt.tval_se_re,'VariableNames',{'Values for Normalized Variables and Derived Values'});
tunval_se_re_t=table(Fopt.tunval_se_re,'VariableNames',{'Values for Un-Normalized Derived Values'});
t_cor_t=table(Fopt.t_cor,'VariableNames',{'Correlations between fit values: Identity matrix if error'});

fprintf(f_id,'%s\n\n',formattedDisplayText(tval_se_re_t,'SuppressMarkup',true,'LineSpacing','compact'));
fprintf(f_id,'%s\n\n',formattedDisplayText(tunval_se_re_t,'SuppressMarkup',true,'LineSpacing','compact'));
fprintf(f_id,'%s\n\n',formattedDisplayText(t_cor_t,'SuppressMarkup',true,'LineSpacing','compact'));

% Assemble x, y, x_fit, y_fit, x_resid, y_resid reuslts for uotput

t_fit=array2table([Fopt.x_FICs' Fopt.y_FICs' Fopt.x_pred' Fopt.y_pred' Fopt.x_resid' Fopt.y_resid']);
tx_fit_vars={'x_FICs' ' y_FICs' 'x_pred' 'y_pred' 'x_resid' 'y_resid'};
tr_fit_vars=replace(tx_fit_vars,'x',Fopt.x_root);
tr_fit_vars=replace(tr_fit_vars,'y',Fopt.y_root);

t_fit.Properties.VariableNames=tr_fit_vars;
tt_fit=table(t_fit,'VariableNames',{'Normalized values, fit values, and residuals'});

fprintf(f_id,'%s\n\n',formattedDisplayText(tt_fit,'SuppressMarkup',true,'LineSpacing','compact'));

fclose(f_id);


end
