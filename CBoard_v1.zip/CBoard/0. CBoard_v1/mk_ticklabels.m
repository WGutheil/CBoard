function [label,ticks] = mk_ticklabels(vals)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    if iscolumn(vals)
        vals=vals';
    end
    label=strsplit(num2str(vals, 2));
    label=label(~cellfun(@isempty,label)); % Get rid of blanks due to no values in a range.
    ticks = linspace(1, length(vals), numel(label));

end