function [Eopt, E1, E2] = G_printCD(C,D,out_dir)
% G_printCD Function to prepared normailzed isobolograms and summary results
% 
% Inputs are C and D structures from x-y and y-x fits. 
% Outputs are: Normalized isobolograms from Mdl_1 and Mdl_2 fits and
% calculated min FICI and min FIC_x and FIC_y values.

% Prepare normalized values. Need MIC0 from x fits to normalize y-axes
% values and vice versa

% First get needed values from x (C) and y (D) fits

for i=1:3
%    clear E
    if i==1
        p_cutoff=0.05;
        title_text=['Best (p<' num2str(p_cutoff,2) ') x-y and y-x Fit Model FIC Analysis'];
    elseif i==2
         p_cutoff=0;
         title_text='Mdl_1 x-y and y-x Fit FIC Analysis';
    else
         p_cutoff=1;
         title_text='Mdl_2 x-y and y-x Fit FIC Analysis';
    end

    E.x_label=C.x_label;        % labels
    E.y_label=C.y_label;
    E.x_root=C.x_root;
    E.y_root=C.y_root;
    
    E.x_MICs=C.x_MICs;
    E.y_MICs=C.y_MICs;

    % Get best Mdl_1 or Mdl_2 values from x and y fits
    % 
    
    if C.pF>p_cutoff                % Get C values from Mdl_1
        E.x_Mdl='Mdl_1';             % Mdl ID
        E.x_pred=C.pred1;
        E.x_resid=E.x_MICs-E.x_pred;
        [E.x_z_score E.x_z_p z_out] = zout(E.x_resid); % For outlier ID
        %E.x_out=find(z_out);
        E.y_MIC0=C.MIC01;           % MIC0 from x fit is the y axis MIC0
        E.se_y_MIC0=C.se_MIC01;
        E.x_K=C.Kd1;                % Kd from x fit is x axis Kd
        E.se_x_K=C.se_Kd1;
        E.x_n=C.n1;                 % n from x fit ix x axis n
        E.se_x_n=C.se_n1; 
    else                            % Get C values from Mdl_2
        E.x_Mdl='Mdl_2';             % Mdl ID
        E.x_pred=C.pred2;
        E.x_resid=E.x_MICs-E.x_pred;
        [E.x_z_score E.x_z_p z_out] = zout(E.x_resid); % For outlier ID
        E.x_out=find(z_out);
        E.y_MIC0=C.MIC02;           % MIC0 from x fit is the y axis MIC0
        E.se_y_MIC0=C.se_MIC02;
        E.x_K=C.Kd2;                % Kd from x fit is x axis Kd
        E.se_x_K=C.se_Kd2;
        E.x_n=C.n2;                 % n from x fit ix x axis n
        E.se_x_n=C.se_n2;
    end

    if D.pF>p_cutoff    % Get D values from Mdl 1
        E.y_Mdl='Mdl_1';
        E.y_pred=D.pred1;
        E.y_resid=E.y_MICs-E.y_pred;
        [E.y_z_score E.y_z_p z_out] = zout(E.y_resid); % For outlier ID
        E.y_out=find(z_out);
        E.x_MIC0=D.MIC01;       % Again MIC0 on other axis
        E.se_x_MIC0=D.se_MIC01;
        E.y_K=D.Kd1;            % Kd from x fit is x axis Kd
        E.se_y_K=D.se_Kd1;
        E.y_n=D.n1;             % n from x fit ix x axis n
        E.se_y_n=D.se_n1;
    else
        E.y_Mdl='Mdl_2';
        E.y_pred=D.pred2;
        E.y_resid=E.y_MICs-E.y_pred;
        [E.y_z_score E.y_z_p z_out] = zout(E.y_resid); % For outlier ID
        E.y_out=find(z_out);
        E.x_MIC0=D.MIC02;       % Again MIC0 on other axis
        E.se_x_MIC0=D.se_MIC02;
        E.y_K=D.Kd2;            % Kd from x fit is x axis Kd
        E.se_y_K=D.se_Kd2;
        E.y_n=D.n2;             % n from x fit ix x axis n
        E.se_y_n=D.se_n2;
    end

    % Next prepare normalized  values. 
    % /MIC0. (Except for n values.)
    E.nx_MICs=E.x_MICs/E.x_MIC0;        % The MIC0 for column MICs is from the y fit fit MIC0
    E.ny_MICs=E.y_MICs/E.y_MIC0;        % And vice versa
    
    E.nx_pred=E.x_pred/E.y_MIC0; 
    E.ny_pred=E.y_pred/E.x_MIC0;
    
    E.re_x_K=E.se_x_K/E.x_K;            % re c_K
    E.re_y_K=E.se_y_K/E.y_K;            % re c_K
    
    E.re_x_MIC0 = E.se_x_MIC0/E.x_MIC0; % re x_MIC0
    E.re_y_MIC0 = E.se_y_MIC0/E.y_MIC0; % re y_MIC0
    
    E.nx_K=E.x_K/E.x_MIC0;                              % z=x/y. Normalize c_K (column k) value
    E.se_nx_K=E.nx_K*sqrt(E.re_x_K^2+E.re_y_MIC0^2);    % Error by propagation of errors:
                                                        % z=x/y, se_z=z*sqrt(re_x^2+re_y^2)
    E.re_nx_K=E.se_nx_K/E.nx_K;                         % re nx_K
    
    E.ny_K=E.y_K/E.y_MIC0;                              % Repeat for y fit k value
    E.se_ny_K=E.ny_K*sqrt(E.re_y_K^2+E.re_x_MIC0^2);    % Repeat for y fit value
    E.re_ny_K=E.se_ny_K/E.ny_K;                         % re ny_K

    if C.pF>p_cutoff % Can calculate FIC_x, FIC_y, and FICI algebraically
        E.x_fitFIC_x = -E.nx_K+sqrt(E.nx_K);                    % x fit FIC_x estimate 
        E.se_x_fitFIC_x = E.se_nx_K*(-1+1/(2*sqrt(E.nx_K)));    % se (propagation of errors)
        E.x_fitFIC_y = sqrt(E.nx_K);                            % x fit FIC_y estimate
        E.se_x_fitFIC_y = E.se_nx_K*(1 / (2*sqrt(E.nx_K)));     % se
        E.x_fitFICI = E.x_fitFIC_x + E.x_fitFIC_y;              % x fit FICI estimate
        E.se_x_fitFICI = E.se_nx_K*(-1+1/sqrt(E.nx_K));        
    else % Have to do numerically
        x=sqrt(E.nx_K);         % Initial estimate
        k=E.nx_K;               % fit Hill Coeff
        n=E.x_n;                % Fit n value in Hill fcn
        fun=@(x) ((1/(1+(x/k).^n)) + x);    % Define function
        x_min=fminsearch(fun,x);            % Find x @ minimum
        y_min=hill_func(x_min,k,n);         % Get y_min
        E.x_fitFIC_x = x_min;
        E.x_fitFIC_y = y_min;
        E.x_fitFICI=fun(x_min);
        % Harder part - getting the se by Propagation of Errors
        % Im a purist!
        dFICI_dk=(FICI_func(x_min,k*1.1,n)-FICI_func(x_min,k*0.9,n))/(0.2*k); % slope relative to k
        dFICI_dn=(FICI_func(x_min,k,n*1.1)-FICI_func(x_min,k,n*0.9))/(0.2*n); % slope relative to n
        E.x_corr_kn=C.corr2(3);                                               % correlation coefficient
        E.se_x_fitFICI = sqrt(  (E.se_nx_K*dFICI_dk)^2 + (E.se_x_n*dFICI_dn)^2 ...
                          +2*E.x_corr_kn*E.se_nx_K*E.se_x_n*dFICI_dk*dFICI_dn );
                         % se by propagation of errors
    end

if D.pF>p_cutoff     % Can calculate FIC_x, FIC_y, and FICI algebraically
    E.y_fitFIC_x = -E.ny_K+sqrt(E.ny_K);  % In text
    E.se_y_fitFIC_x = E.se_ny_K*(-1+1/(2*sqrt(E.ny_K))); % Prop errors
    E.y_fitFIC_y = sqrt(E.ny_K);          % In text
    E.se_y_fitFIC_y = E.se_ny_K*(1/(2*sqrt(E.ny_K)));   %Prop errors
    E.y_fitFICI = E.y_fitFIC_x + E.y_fitFIC_y;
    E.se_y_fitFICI = E.se_ny_K*(-1+1/sqrt(E.ny_K));
else                % Or have to do numerically
    x=sqrt(E.ny_K);
    k=E.ny_K;
    n=E.y_n;
    fun=@(x) ((1/(1+(x/k).^n)) + x);
    x_min=fminsearch(fun,x);
    y_min=hill_func(x_min,k,n);
    E.y_fitFIC_x = x_min;
    E.y_fitFIC_y = y_min;
    E.y_fitFICI=fun(x_min);
    dFICI_dk=(FICI_func(x_min,k*1.1,n)-FICI_func(x_min,k*0.9,n))/(0.2*k);
    dFICI_dn=(FICI_func(x_min,k,n*1.1)-FICI_func(x_min,k,n*0.9))/(0.2*n);
    E.y_corr_kn=D.corr2(3);
    E.se_y_fitFICI = sqrt(  (E.se_ny_K*dFICI_dk)^2 + (E.se_y_n*dFICI_dn)^2 ...
                      +2*E.y_corr_kn*E.se_ny_K*E.se_y_n*dFICI_dk*dFICI_dn );
end

% [E.c_dataFICI I]=min([E.nx_conc'+E.nx_MICs']); % Col dataFICI
% E.c_dataFIC_x=E.nx_conc(I);
% E.c_dataFIC_y=E.nx_MICs(I);
% 
% [E.r_dataFICI I]=min([E.ny_conc'+E.ny_MICs']); % Row dataFICI
% E.r_dataFIC_x=E.ny_conc(I);
% E.r_dataFIC_y=E.ny_MICs(I);
% 

figure('units','inches','position',[1 0.5 7 9.5]);
fnum=6+i;
sgtitle(['Fig ' num2str(fnum,1) '; ' title_text], 'Interpreter','none');

subplot(3,2,1)
hold off
plot(E.nx_MICs, E.ny_MICs, '.','MarkerSize', 20)            % Data
hold on
% plot(E.nx_conc,E.nx_pred, '.')   % Useful for error checking
x=[0:.01:1];
k=E.nx_K;
n=E.x_n;
plot(x, hill_func(x, k, n),'-','LineWidth',1.5)             % Fit curve
% plot([0 1], [1 0],'-','LineWidth',1.5)                      % No interaction line
plot(E.x_fitFIC_x,E.x_fitFIC_y,'or','MarkerSize',10,'LineWidth',2)        % fit FICI marker
% plot(E.c_dataFIC_x,E.c_dataFIC_y,'bO','MarkerSize',12)
plot([0 E.x_fitFIC_x E.x_fitFIC_x], [E.x_fitFIC_y E.x_fitFIC_y 0],...
                                      '-','LineWidth',1.5); % FIC_x/y lines
plot([0 E.x_fitFICI],[E.x_fitFICI 0],'-','LineWidth',1.5);  % m=1 FICI intercept
mlim=max([xlim ylim]);
yticks([0:0.1:mlim]);
xticks([0:0.1:mlim]);
xlim([0 mlim]);
ylim([0 mlim]);
title(['Normalized x-y Fit: ' E.x_Mdl],'Interpreter','none')
xlabel(['MIC/MIC0 ' E.x_root],'Interpreter','none')
ylabel(['MIC/MIC0 ' E.y_root],'Interpreter','none')
lgd=legend({'data' 'fit' 'fitFICI point' 'fitFIC_x/y lines' ... 
    'm = -1 FICI intercept line'}, 'Interpreter','None', 'Location','northeast');
lgd.FontSize = 8;
lgd.BackgroundAlpha = .6;
clear xlim ylim mlim
hold off

subplot(3,2,2)
hold off
plot(E.ny_MICs, E.nx_MICs, '.','MarkerSize', 20)            % Data
hold on
% plot(E.ny_conc,E.ny_pred, '.','MarkerSize', 20)   % Useful for error checking
x=[0:.01:1];
k=E.ny_K;
n=E.y_n;
plot(x, hill_func(x, k, n),'-','LineWidth',1.5)                     % Fit curve
% plot([0 1], [1 0],'-','LineWidth',1.5)                            % No interaction line
plot(E.y_fitFIC_x,E.y_fitFIC_y,'or','MarkerSize',10,'LineWidth',2)  % fit FICI marker
% plot(E.r_dataFIC_x,E.r_dataFIC_y,'bO','MarkerSize',12)
plot([0 E.y_fitFIC_x E.y_fitFIC_x], [E.y_fitFIC_y E.y_fitFIC_y 0],...
                                      '-','LineWidth',1.5); % FIC_x/y lines
plot([0 E.y_fitFICI],[E.y_fitFICI 0],'-','LineWidth',1.5);  % m=1 FICI intercept
mlim=max([xlim ylim]);
yticks([0:0.1:mlim]);
xticks([0:0.1:mlim]);
xlim([0 mlim]);
ylim([0 mlim]);
title(['Normalized y-x Fit: ' E.y_Mdl],'Interpreter','none')
xlabel(['MIC/MIC0 ' E.y_root],'Interpreter','none')
ylabel(['MIC/MIC0 ' E.x_root],'Interpreter','none')
lgd=legend({'data' 'fit' 'fitFICI point' 'fitFIC_x/y lines' ... 
    'm = -1 FICI intercept line'}, 'Interpreter','None', 'Location','northeast');
lgd.FontSize = 8;
lgd.BackgroundAlpha = .6;
clear xlim ylim mlim
hold off

% Not reporting se's for FICs since getting numerically is a bit
% complicated.
% figure('units','inches','position',[1 0.5 7 9.5]);
subplot(3,2,3)
if strcmp(E.x_Mdl,'Mdl_1')
     str_out={
     ['Normalized x-y ' E.x_Mdl ' Fit:'];
     ['k (norm) = ' num2str(E.nx_K,3) ' +/-' num2str(E.se_nx_K,2)];
     [''];
     ['Algebraically calculated:'];
     ['minFIC_' E.x_root ' = -k+sqrt(k)' ]; 
     ['                    = '  num2str(E.x_fitFIC_x,3)]; % ' +/- ' num2str(E.se_x_fitFIC_x,2)];
     ['minFIC_' E.y_root ' = sqrt(k)'];
     ['                    = ' num2str(E.x_fitFIC_y,3)]; % ' +/- ' num2str(E.se_x_fitFIC_y,2)];
     ['minFICI        = -k+2*sqrt(k)']; 
     ['                    = ' num2str(E.x_fitFICI,3) ' +/- ' num2str(E.se_x_fitFICI,2)];         
     };
else
     str_out={
     ['Normalized x-y ' E.x_Mdl ' Fit:'];
     ['k (norm) = ' num2str(E.nx_K,3) ' +/-' num2str(E.se_nx_K,2)];
     [''];     
     ['Numerically calculated:'];
     ['minFIC_' E.x_root ' = ' num2str(E.x_fitFIC_x,3)]; % ' +/- ' num2str(E.se_x_fitFIC_x,2)];
     ['minFIC_' E.y_root ' = ' num2str(E.x_fitFIC_y,3)]; % ' +/- ' num2str(E.se_x_fitFIC_y,2)];
     ['minFICI' ' = ' num2str(E.x_fitFICI,3) ' +/- ' num2str(E.se_x_fitFICI,2)];         
     };
end
xticks([]);
yticks([]);
text(0.05,0.95,str_out,'normalize','Interpreter','none','FontSize', 8,'VerticalAlignment','top');
title('x-y Fit FIC Summary');
hold off

subplot(3,2,4)
if strcmp(E.y_Mdl,'Mdl_1')
     str_out={         
     ['Normalized y-x ' E.y_Mdl ' Fit:'];
     ['k (norm) = ' num2str(E.ny_K,3) ' +/- ' num2str(E.se_ny_K,2) ')'];
     [''];
     ['Algebraically calculated:'];
     ['minFIC_' E.y_root ' = -k+sqrt(k)']; 
     ['                    = '  num2str(E.y_fitFIC_x,3)]; % ' +/- ' num2str(E.se_y_fitFIC_x,2)];
     ['minFIC_' E.x_root ' = sqrt(k)'];
     ['                    = ' num2str(E.y_fitFIC_y,3)]; % ' +/- ' num2str(E.se_y_fitFIC_x,2)];
     ['minFICI        = -k+2*sqrt(k)']; 
     ['                    = ' num2str(E.y_fitFICI,3) ' +/- ' num2str(E.se_y_fitFICI,2)];         
     };
else
     str_out={
     ['Normalized y-x ' E.y_Mdl ' Fit:'];
     ['k (norm) = ' num2str(E.ny_K,3) ' +/- ' num2str(E.se_ny_K,2)];
     [''];
     ['Numerically calculated:']
     ['minFIC_' E.y_root ' = ' num2str(E.y_fitFIC_x,3)]; % ' +/- ' num2str(E.se_y_fitFIC_y,2)];
     ['minFIC_' E.x_root ' = ' num2str(E.y_fitFIC_y,3)]; % ' +/- ' num2str(E.se_y_fitFIC_x,2)];
     ['minFICI' ' = ' num2str(E.y_fitFICI,3) ' +/-' num2str(E.se_y_fitFICI,2)];         
     };
end
xticks([]);
yticks([]);
text(0.05,0.95,str_out,'normalize','Interpreter','none','FontSize', 8,'VerticalAlignment','top');
title('y-x Fit FIC Summary');
hold off

hold off
subplot(3,2,5)
plot(E.nx_MICs, E.ny_MICs, '.','MarkerSize', 20) % Col data
hold on
% plot(E.nx_conc,E.nx_pred, 'b.','MarkerSize', 20)
x=[0:.01:1];
k=E.nx_K;
n=E.x_n;
plot(x, hill_func(x, k, n),  '-','LineWidth',1.5) % Col fit
mlim=max([xlim ylim]);
yticks([0:0.1:mlim]);
xticks([0:0.1:mlim]);
xlim([0 mlim]);
ylim([0 mlim]);
xlabel(['MIC/MIC0 ' E.x_root],'Interpreter','none')
ylabel(['MIC/MIC0 ' E.y_root],'Interpreter','none')
% plot(E.ny_MICs, E.nx_MICs, 'b.','MarkerSize', 20) % Row data
k=E.ny_K;
n=E.y_n;
plot(hill_func(x, k, n), x, '-','LineWidth',1.5) % y fit fit
% plot(E.ny_pred, E.ny_conc, 'k.','MarkerSize', 20)   % Predicteds - useful for error checking
title(['Overlay of x-y and y-x fits'])
lgd=legend({'data' 'x-y fit' 'y-x fit'},'Location','northeast');
lgd.BackgroundAlpha = .6;
clear xlim ylim mlim
hold off

% Calculate avg x_FIC, y_FIC, and FICI from x-y and y-x fit values.
% Use average, sd, and se values between the two different estimates.
[E.x_sdFIC E.x_avgFIC] = std([E.x_fitFIC_x E.y_fitFIC_y]);
E.x_seFIC=E.x_sdFIC/sqrt(2);
[E.y_sdFIC E.y_avgFIC] = std([E.x_fitFIC_y E.y_fitFIC_x]);
E.y_seFIC=E.y_sdFIC/sqrt(2);
[E.sdFICI E.avgFICI] = std([E.x_fitFICI E.y_fitFICI]);
E.seFICI=E.sdFICI/sqrt(2);

subplot(3,2,6)
str_out={         
['Mean min FIC_x, FIC_y, '];
['and FICI Values and SEs.'];
['Average and SEs of x-y '];
['and y-x values.'];
[''];
['minFIC_' E.x_root ' = ' num2str(E.x_avgFIC,3) ' +/- ' num2str(E.x_seFIC,2)];
['minFIC_' E.y_root ' = ' num2str(E.y_avgFIC,3) ' +/- ' num2str(E.y_seFIC,2)];
['minFICI  = ' num2str(E.avgFICI,3) ' +/- ' num2str(E.seFICI,2)];
};
xticks([]);
yticks([]);
text(0.05,0.95,str_out,'normalize','Interpreter','none','FontSize', 8,'VerticalAlignment','top');
title('Mean Values Fit FIC Summary');
hold off

%% Print Fig
fnum=6+i;
if i==1
    print([out_dir,'\Fig' num2str(fnum,1) '; Best Fit x-y and y-x Model FIC Analysis.pdf'],'-dpdf','-fillpage');
else
    print([out_dir,'\Fig' num2str(fnum,1) '; ' title_text '.pdf'],'-dpdf','-fillpage');
end

% If i==1 then these are the optimized values. Save them to be returned at
% the end.
if i==1
    Eopt=E;
elseif i==2
    E1=E;
elseif i==3
    E2=E;
end

end

end