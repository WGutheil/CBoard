function [A] = chk_col_fit(data, r_conc, c_conc)
% UNTITLED2 Summary of this function goes here
%   Columnwise extraction of MICs

% Get indicies of fitable columns
[ic,Alow,Amid,Ahigh] = Ba_icolfit(data, r_conc, c_conc);

% Truncate data to just those columns with substantial delta A range
dataic=data(:,ic);
c_concic=c_conc(ic); % And for corresponding column Ab concentrations.

%% First get rough estimates
ddata=dataic-Amid;
[M,I]= min(abs(ddata));
clear K;
K=r_conc(I)+0.001; % Get an estimate from r_conc closest to A midpoint. Add 
                   % small amount to make sure K est not zero.

%% Set up for fit of just Ks with all other variables fixed.
n=1;
x=r_conc;
clear Kn 
g=fittype("Alow-(Alow-Ahigh)*(x^n/(x^n + K^n))", ...
    'problem',{'Alow', 'Ahigh', 'n'},...
    independent="x");
RSS=0;
sdf=0; % sum of dfreedom
for i=1:length(c_concic)
    y=dataic(:,i);
    [fo,gof]=fit(x,y,g,...    
        'problem', {Alow, Ahigh, n},...
        'startpoint', [K(i)]); 
    Kn(i)=coeffvalues(fo);    % Get fit value
    % sKn(i)=diff(confint(fo))/(2*1.96); % convert 95% confidence intervals to sigmas
    % [Kn(i) sKn(i)]; % scroll results
    % RSS=RSS+gof.sse;
    % sdf=sdf+gof.dfe;
    % subplot(1,2,1);
    % plot(fo,x,y)
    % title(['K = ', num2str(Kn(i))]);
    % subplot(1,2,2)
    % loglog(x,y,'.',x,fo(x));
    % legend({'data' 'fit'})
    % title('loglog');
    % pause
end

%% Then fit Ks and ns
clear nn sKn
g=fittype("Alow-(Alow-Ahigh)*(x^n/(x^n + K^n))", ...
    'problem',{'Alow', 'Ahigh'},...
    independent="x");
    RSS=0;
    sdf=0; % sum of dfreedom
% options=fitoptions(g);
ifail=[];
for i=1:length(c_concic);
    try
        y=dataic(:,i);
        [fo,gof]=fit(x,y,g,...    
            'problem', {Alow, Ahigh},...
            'startpoint', [Kn(i) n],...
            'lower',[0 1.2]); 
        tmp=coeffvalues(fo);
        Knn(i) = tmp(1); 
        nn(i) = tmp(2);
        %[Knn(i) nn(i)];
        % tmp=diff(confint(fo))/(2*1.96); % convert 95% confidence intervals to sigmas
        % sKnn(i)=tmp(1); 
        % snn(i) = tmp(2);
        % [sKnn(i) snn(i)];
        % RSS=RSS+gof.sse;
        % sdf=sdf+gof.dfe;
        % subplot(1,2,1);
        % plot(fo,x,y)
        % title(['K = ', num2str(Kn(i)), '; n = ', num2str(nn(i))]);
        % subplot(1,2,2)
        % loglog(x,y,'.',x,fo(x));
        % legend({'data' 'fit'})
        % title('loglog');
        % pause
        ifail(i)=1;
    catch
        ifail(i)=0;
    end
end
fifail=find(ifail);
ic=ic(fifail); % index for if col/row unfittable, use remove from fitable list
% Truncate data to just those columns with substantial delta A range
dataic=data(:,ic);
c_concic=c_conc(ic); % And for corresponding column Ab concentrations.
Knn=Knn(fifail);
nn=nn(fifail);
% sKnn=sKnn(fifail);
% snn=snn(fifail)
%% Next, setup to globally fit Alow and Ahigh plus Ks and ns.
clear x0 x
[la,lic]=size(dataic);
x0(1)=Alow; x0(2)=Ahigh;
x0([3:3+1*lic-1])=Knn;
x0(3+lic:3+2*lic-1)=nn;

%% Section for fminunc fitting: Works best - use
options=optimoptions('fminunc');
% options.MaxIterations=10000;
options.MaxFunctionEvaluations=200000;
options.StepTolerance=1e-7;
options.HessianApproximation='dfp';
% options.Display='iter';

f=@(x)col_fit(x,r_conc,dataic);
[x,fval,exitf,output,grad,hessian]=fminunc(f,x0,options);
% exitf
df=size(dataic(:),1)-length(x);
se=sqrt(abs(diag(pinv(hessian))*(fval/df)));
% p_hess=pinv(hessian)
% corr=corrcov(pinv(hessian));   % correlation matrix
%[x0' x' sd]

%% Finish up

[y_est, resid]=col_fit_2nd(x,r_conc,dataic);

function xylabel()
    xticklabels=strsplit(num2str(c_concic,3));
    xticks = linspace(1, size(dataic, 2), numel(xticklabels));
    set(gca, 'XTick', xticks, 'XTickLabel', xticklabels);
    set(gca,'xaxisLocation','bottom');
    xlabel('Column [ ]')
    
    yticklabels=strsplit(num2str(r_conc',3));
    yticks = linspace(1, size(dataic, 1), numel(yticklabels));
    set(gca, 'YTick', yticks, 'YTickLabel', yticklabels(:));
    ylabel('Row [ ]');
end


%% Reformat for output
[la,lic]=size(dataic);
A.data=data;
A.r_conc=r_conc;
A.c_conc=c_conc;
A.ic=ic;
A.dataic=dataic;
A.pred=y_est;
A.resid=resid;
A.r_conc=r_conc;
A.c_concic=c_concic;
A.Alow=x(1);
A.seAlow=se(1);
A.Ahigh=x(2);
A.seAhigh=se(2);
A.Kf=x([3:3+1*lic-1]);
A.seKf=se([3:3+1*lic-1])';
A.nf=x(3+lic:3+2*lic-1);
A.senf=se(3+lic:3+2*lic-1)';
% A.corr=corr;


end
