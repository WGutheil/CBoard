function [] = E_printAfit(A,out_dir)
%UNTITLED Summary of this function goes here
%  Detailed explanation goes here

    if inputname(1)=='A'
        Ftitle='Column';
        i_title='Rpt1;';
    elseif inputname(1)=='B'
        Ftitle='Row';
        i_title='Rpt2;';
    end
    Z=A; % Temporary
    foutname=[out_dir '\' i_title ' ' Ftitle 'GlobalFit.txt'];
    f_id=fopen(foutname,'w');
    fprintf(f_id,'%s\n\n',[i_title ' ' Ftitle ' Fit Results']);
    fprintf(f_id,'%s\n',['GLOBAL PARAMETERS']);
    fprintf(f_id,'%s\n',['Alow = ' num2str(Z.Alow,3) ', seAlow = ' num2str(Z.seAlow,2)]);
    fprintf(f_id,'%s\n\n',['Ahigh = ' num2str(Z.Ahigh,3) ', seAhigh = ' num2str(Z.seAhigh,2)]);

    fprintf(f_id,'%s\n',[Ftitle '-WISE PARAMETERS: First two columns are for col/row IDs and concentration.']);
    fprintf(f_id,'%s\n\n',['The other columns are for the fit midpoints (MICs) and n values.']);

    tmp=table(Z.ic',Z.c_concic',Z.Kf',Z.seKf',Z.nf',Z.senf');
    if length(Z.c_root)>0
        n_str=['n_' Z.c_root];
    else
        n_str=['n'];
    end
    tmp.Properties.VariableNames={'RowCol_ID' Z.c_label ['MIC_' Z.r_label] ['se_MIC_' Z.r_label] ...
        n_str 'se_n'};
    str=formattedDisplayText(tmp,'SuppressMarkup',true,'NumericFormat','shortG');
    fprintf(f_id,str);

    clear tmp
    % tmp(2:lr+1,2:lc+1)=Z.dataic;
    % tmp(2:lr+1,1)=Z.r_conc;
    % tmp(1,2:lc+1)=Z.c_concic;
    str=formattedDisplayText(Z.pred,'SuppressMarkup',true,'NumericFormat','shortG');
    fprintf(f_id,'\n\n%s\n',['PREDICTED VALUES. The original raw data is in the parent Worksheet.']);
    fprintf(f_id,'\n');
    fprintf(f_id,str);

    % fprintf(f_id, '%s\n', ['Col_ID  '   [c_label] ['    MIC_' r_label] [' seMIC_' r_label] ...
    %                               '  n' '  se_n']);
    % for i=1:length(Z.ic)
    %     fprintf(f_id, '   %i      ',Z.ic(i)) 
    %     fprintf(f_id,'%s\n',[num2str(Z.c_concic(i),3) '         ' ...
    %         num2str(Z.Kf(i),3) '       ' num2str(Z.seKf(i),2) '      ' ...
    %         num2str(Z.nf(i),3) '    ' num2str(Z.senf(i),2)]);
    % end

    fclose(f_id);      
end